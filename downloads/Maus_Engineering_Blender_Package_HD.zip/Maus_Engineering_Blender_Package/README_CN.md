# 鼠式工程型超重型坦克 · 高精度外观版

`ready/` 已放入生成好的文件。

- `Maus_Engineering.blend` 是可编辑工程，贴图已打包。第 1 帧抬铲，第 36 帧放铲，液压杆与铲架联动。
- `Maus_Engineering.glb` 是带内嵌 PBR 贴图的模型。保留炮塔、炮管、推土铲和左右履带的轴点，以及铲架动画。Blender 使用米和 −Y 车头，GLB 使用米和 +Z 车头。
- `renders/` 包含前斜、左侧、正面、车尾和顶视渲染。

重新生成时，解压整个文件夹，再双击对应启动文件。需要已安装的 Blender 4.2 或更新版本，启动器会在后台调用它。

| 系统 | 快速生成 | 同时渲染五个角度 |
| --- | --- | --- |
| Windows | `Build_Maus_Engineering.cmd` | `Build_Maus_Engineering_FULL.cmd` |
| macOS | `Build_Maus_Engineering.command` | `Build_Maus_Engineering_FULL.command` |

生成结果在 `output/Maus_Engineering/`。重复生成会写入新的编号文件夹。自定义 Blender 安装位置可通过环境变量 `BLENDER_EXE` 指定。

模型依据库宾卡现存鼠式的外观重做，沿用游戏版主体尺寸和轴点。推土铲、油路与其安装架属于虚构的工程改装，迷彩和磨损为本版绘制。[车首与侧甲参考](https://commons.wikimedia.org/wiki/File:Maus_2025_b.jpg) · [车尾参考](https://commons.wikimedia.org/wiki/File:Maus_rear_2025.jpg)
