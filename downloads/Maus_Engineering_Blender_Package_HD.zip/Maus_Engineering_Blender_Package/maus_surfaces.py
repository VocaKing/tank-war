"""Portable UV textures for the painted, exposed and running surfaces."""

from math import ceil

import bpy
import numpy as np


def noise(size, columns, rows, seed):
    """Cubic-interpolated periodic value noise."""
    rng = np.random.default_rng(seed)
    grid = rng.random((rows, columns), dtype=np.float32)
    x = np.arange(size, dtype=np.float32) * (columns / size)
    y = np.arange(size, dtype=np.float32) * (rows / size)
    ix, iy = x.astype(np.int32), y.astype(np.int32)
    u, v = x - ix, y - iy
    u = u * u * (3.0 - 2.0 * u)
    v = (v * v * (3.0 - 2.0 * v))[:, None]
    a = grid[iy[:, None], ix] * (1 - u) + grid[iy[:, None], (ix + 1) % columns] * u
    b = grid[((iy + 1) % rows)[:, None], ix] * (1 - u) + grid[((iy + 1) % rows)[:, None], (ix + 1) % columns] * u
    return (a * (1 - v) + b * v).astype(np.float32)


def ease(low, high, field):
    t = np.clip((field - low) / (high - low), 0, 1)
    return t * t * (3.0 - 2.0 * t)


def mix(first, second, mask):
    t = mask[:, :, None]
    return first * (1 - t) + second * t


def pixels(name, rgb, color=True):
    size = rgb.shape[0]
    rgba = np.ones((size, size, 4), dtype=np.float32)
    rgba[:, :, :3] = np.clip(rgb, 0.0, 1.0)
    image = bpy.data.images.new(name, width=size, height=size, alpha=False)
    image.colorspace_settings.name = "sRGB" if color else "Non-Color"
    image.pixels.foreach_set(rgba.ravel())
    image.update()
    image.file_format = "PNG"
    image.pack()
    return image


def maps(name, color, rough, metal, height):
    # The normal image is tangent-space, so it travels with the exported mesh.
    dx = (np.roll(height, -1, 1) - np.roll(height, 1, 1))
    dy = (np.roll(height, -1, 0) - np.roll(height, 1, 0))
    normal = np.stack((-dx, -dy, np.ones_like(height)), axis=-1)
    normal /= np.linalg.norm(normal, axis=-1, keepdims=True)
    orm = np.stack((np.ones_like(rough), rough, np.broadcast_to(metal, rough.shape)), axis=-1)
    return (pixels(name + " | BaseColor", color), pixels(name + " | MetallicRoughness", orm, False),
            pixels(name + " | Normal", normal * 0.5 + 0.5, False))


def paint_maps():
    s = 1024
    field = 0.69 * noise(s, 5, 7, 157) + 0.23 * noise(s, 10, 9, 219) + 0.08 * noise(s, 30, 32, 96)
    umber = ease(0.33, 0.38, field) * (1 - ease(0.48, 0.55, field))
    green = ease(0.53, 0.59, field)
    broad = noise(s, 6, 7, 23)
    fine = noise(s, 110, 123, 6)
    grain = noise(s, 306, 314, 16)
    streak = noise(s, 132, 12, 41)
    color = mix(np.array([0.54, 0.472, 0.329], dtype=np.float32),
                np.array([0.275, 0.207, 0.142], dtype=np.float32), umber)
    color = mix(color, np.array([0.274, 0.311, 0.206], dtype=np.float32), green)
    color *= (0.84 + 0.28 * broad + 0.09 * fine - 0.11 * streak)[:, :, None]
    rain = ease(0.72, 0.94, streak) * ease(0.31, 0.73, noise(s, 20, 16, 90)) * 0.22
    color = mix(color, np.array([0.23, 0.175, 0.114], dtype=np.float32), rain)
    chips = ease(0.79, 0.95, fine * 0.70 + grain * 0.30) * ease(0.48, 0.72, noise(s, 36, 39, 51))
    shadow = np.maximum(np.roll(chips, 1, 0), np.roll(chips, -1, 1)) * 0.42
    color = mix(color, np.array([0.16, 0.13, 0.099], dtype=np.float32), shadow)
    color = mix(color, np.array([0.39, 0.347, 0.268], dtype=np.float32), chips)
    rough = np.clip(0.62 + 0.12 * broad - 0.08 * streak + 0.1 * chips, 0.49, 0.86)
    return maps("Painted armor", color, rough, 0.012 + chips * 0.56,
                0.08 * fine + 0.06 * grain + 0.12 * shadow)


def steel_maps(name, dark, light, seed, s, polish, directional):
    coarse = noise(s, 13, 12, seed)
    fine = noise(s, 80, 75, seed + 9)
    grain = noise(s, ceil(s * 0.32), ceil(s * 0.38), seed + 7)
    columns, rows = {"vertical": (165, 9), "horizontal": (8, 165)}.get(directional, (53, 37))
    brush = noise(s, columns, rows, seed + 32)
    dirt = ease(0.50, 0.78, coarse * 0.76 + fine * 0.24)
    mix_factor = np.clip(0.19 + 0.49 * brush + 0.16 * fine + 0.14 * grain - 0.41 * dirt, 0, 1)
    color = mix(np.array(dark, dtype=np.float32), np.array(light, dtype=np.float32), mix_factor)
    rust = noise(s, 34, 48, seed + 30)
    rust = ease(0.64, 0.80, rust * 0.68 + coarse * 0.32) * (1 - polish) * 0.70
    color = mix(color, np.array([0.29, 0.193, 0.113], dtype=np.float32), rust)
    scour = ease(0.80, 0.97, brush * 0.8 + fine * 0.2) * (0.20 + polish * 0.4)
    color = mix(color, np.array(light, dtype=np.float32), scour)
    rough = np.clip(0.71 - 0.38 * polish + 0.15 * dirt + 0.15 * rust - brush * 0.12 - scour * 0.12, 0.27, 0.92)
    metal = np.clip(0.72 + 0.23 * polish - dirt * 0.35 - rust * 0.35, 0, 1)
    return maps(name, color, rough, metal, brush * (0.08 if directional else 0.15) + fine * 0.065 + grain * 0.05)


def attach_maps(mat, textures, strength):
    tree = mat.node_tree
    shader = tree.nodes.get("Principled BSDF")
    diffuse, packed, normal = (tree.nodes.new("ShaderNodeTexImage") for _ in range(3))
    diffuse.image, packed.image, normal.image = textures
    for i, node in enumerate((diffuse, packed, normal)):
        node.location = (-570, 290 - i * 320)
    split = tree.nodes.new("ShaderNodeSeparateColor")
    split.mode = "RGB"
    split.location = (-245, 20)
    tangent = tree.nodes.new("ShaderNodeNormalMap")
    tangent.inputs["Strength"].default_value = strength
    tangent.location = (-240, -260)
    tree.links.new(diffuse.outputs["Color"], shader.inputs["Base Color"])
    tree.links.new(packed.outputs["Color"], split.inputs["Color"])
    tree.links.new(split.outputs["Green"], shader.inputs["Roughness"])
    tree.links.new(split.outputs["Blue"], shader.inputs["Metallic"])
    tree.links.new(normal.outputs["Color"], tangent.inputs["Color"])
    tree.links.new(tangent.outputs["Normal"], shader.inputs["Normal"])


def apply_material_maps(mats):
    paint = paint_maps()
    raw = steel_maps("Oxidized structural steel", (0.108, 0.105, 0.09), (0.35, 0.32, 0.262), 272, 512, 0.13, None)
    slide = steel_maps("Abrasive wear", (0.15, 0.156, 0.144), (0.52, 0.523, 0.487), 316, 768, 0.51, "vertical")
    lip = steel_maps("Burnished edges", (0.28, 0.26, 0.226), (0.62, 0.61, 0.56), 120, 512, 0.85, "horizontal")
    for key in ("hull", "turret"):
        attach_maps(mats[key], paint, 0.50)
    for key in ("track", "exhaust"):
        attach_maps(mats[key], raw, 0.46)
    attach_maps(mats["blade"], slide, 0.39)
    attach_maps(mats["polished"], lip, 0.24)


def project_uv(mesh, at=(0, 0, 0)):
    """Consistent metric scale, with distinct side, roof and end projections."""
    layer = mesh.uv_layers.new(name="Surface")
    mesh.update()
    for face in mesh.polygons:
        n = face.normal
        axis = max(range(3), key=lambda i: abs(n[i]))
        name = mesh.materials[face.material_index].name
        scale = 0.19 if "camouflage" in name else 0.72 if "Moldboard" in name else 1.08
        for li in face.loop_indices:
            x, y, z = mesh.vertices[mesh.loops[li].vertex_index].co
            x, y, z = x + at[0], y + at[1], z + at[2]
            if axis == 0:
                uv = (y * scale, z * scale)
            elif axis == 1:
                uv = (x * scale + 0.318, z * scale)
            else:
                uv = (x * scale - 0.206, y * scale + 0.177)
            layer.data[li].uv = uv
