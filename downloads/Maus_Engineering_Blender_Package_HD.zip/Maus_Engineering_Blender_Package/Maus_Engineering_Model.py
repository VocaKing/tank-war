"""Steel Front — Maus Engineering Variant, editable Blender model.

In Blender, open this file in Scripting > Text Editor and choose Run Script.
The model is built in its own scene. Save your edited result as a .blend file.
Frame 1 shows the blade raised. Frame 36 shows the blade lowered.
Track shoes use two linked meshes: contact shoe and connector.

Scale: metres. Ground: Z = 0. Front: -Y (becomes +Z in Y-up glTF).
Hull: 9.00 x 3.70 m excluding the blade. No external textures are needed.
"""

from math import cos, pi, radians, sin, tau
from pathlib import Path
from runpy import run_path
from typing import NamedTuple

import bpy
from mathutils import Matrix, Vector


class Dimensions(NamedTuple):
    length: float = 9.0
    width: float = 3.7
    hull_roof: float = 2.08
    clearance: float = 0.48
    track_width: float = 1.02
    turret_y: float = 0.87
    turret_length: float = 3.65
    turret_width: float = 2.85
    turret_height: float = 1.17
    barrel_length: float = 4.30


_SURFACES = run_path(str(Path(__file__).resolve().with_name("maus_surfaces.py")))
project_uv = _SURFACES["project_uv"]
apply_material_maps = _SURFACES["apply_material_maps"]

D = Dimensions()
SCENE_NAME = "Maus Engineering HD"
SCENE_KEY = "steel_front_maus_engineering"
FRONT = (pi / 2, 0, 0)
REAR = (-pi / 2, 0, 0)
REAR_MATRIX = Matrix.Rotation(REAR[0], 4, "X")
ACROSS = (0, pi / 2, 0)
FRAME_TRAVEL = 1
FRAME_WORK = 36


def linear_color(color):
    def channel(value):
        value /= 255.0
        return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4

    return tuple(channel(int(color[i:i + 2], 16)) for i in (0, 2, 4)) + (1.0,)


def material(name, color, roughness, metallic=0.0, grain=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.diffuse_color = linear_color(color)
    mat.metallic = metallic
    mat.roughness = roughness
    tree = mat.node_tree
    shader = tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = mat.diffuse_color
    shader.inputs["Metallic"].default_value = metallic
    shader.inputs["Roughness"].default_value = roughness
    if grain:
        coords = tree.nodes.new("ShaderNodeTexCoord")
        coords.location = (-760, 50)
        grit = tree.nodes.new("ShaderNodeTexNoise")
        grit.inputs["Scale"].default_value = 105.0
        grit.inputs["Detail"].default_value = 2.0
        grit.location = (-555, -170)
        bump = tree.nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = grain
        bump.inputs["Distance"].default_value = 0.015
        bump.location = (-180, -160)
        tree.links.new(coords.outputs["Object"], grit.inputs["Vector"])
        tree.links.new(grit.outputs["Fac"], bump.inputs["Height"])
        tree.links.new(bump.outputs["Normal"], shader.inputs["Normal"])
    return mat


def make_materials():
    return {
        "hull": material("01 Hull | field camouflage", "756849", 0.66),
        "turret": material("02 Turret | field camouflage", "756849", 0.66),
        "olive": material("03 Fittings | muted olive", "535A45", 0.63, 0.27, 0.16),
        "blade": material("04 Moldboard | worn steel", "4F5651", 0.68, 0.53, 0.28),
        "track": material("05 Track shoes | oxidized steel", "514B42", 0.69, 0.65, 0.28),
        "polished": material("06 Contact edges | burnished steel", "8C887C", 0.42, 0.75, 0.14),
        "dark": material("07 Recesses | carbon grey", "252A28", 0.76, 0.29, 0.20),
        "rubber": material("08 Wheel bands | charcoal", "292925", 0.84, 0.02, 0.16),
        "glass": material("09 Periscopes | blue-grey glass", "5B7879", 0.24, 0.32),
        "lamp": material("10 Lamps | warm glass", "C6C0A1", 0.28, 0.15),
        "amber": material("11 Recovery markings | faded ochre", "B89549", 0.61, 0.16),
        "exhaust": material("12 Exhaust | heat-stained steel", "544539", 0.70, 0.61, 0.28),
        "weld": material("13 Welds and fasteners | weathered alloy", "4E4739", 0.69, 0.43),
    }


def child_collection(name, parent):
    collection = bpy.data.collections.new(name)
    parent.children.link(collection)
    return collection


def pivot(name, collection, parent=None, position=(0, 0, 0), size=0.22):
    obj = bpy.data.objects.new(name, None)
    collection.objects.link(obj)
    obj.empty_display_type = "PLAIN_AXES"
    obj.empty_display_size = size
    obj.parent = parent
    obj.location = position
    return obj


class MeshParts:
    """Small mesh builder for reusable wheels, track shoes and lathes."""

    def __init__(self):
        self.vertices = []
        self.faces = []
        self.face_materials = []
        self.smooth = []

    def add(self, vertices, faces, color, smooth=False):
        offset = len(self.vertices)
        self.vertices.extend(vertices)
        self.faces.extend(tuple(offset + index for index in face) for face in faces)
        self.face_materials.extend([color] * len(faces))
        self.smooth.extend([smooth] * len(faces) if isinstance(smooth, bool) else smooth)

    def box(self, size, at=(0, 0, 0), color="olive"):
        hx, hy, hz = (value / 2 for value in size)
        cx, cy, cz = at
        points = [(-hx, -hy), (hx, -hy), (hx, hy), (-hx, hy)]
        vertices = [(cx + x, cy + y, cz + z) for z in (-hz, hz) for x, y in points]
        faces = [(3, 2, 1, 0), (4, 5, 6, 7)]
        faces.extend((i, (i + 1) % 4, (i + 1) % 4 + 4, i + 4) for i in range(4))
        self.add(vertices, faces, color)

    def lathe(self, rings, sides, color, at=(0, 0, 0), inside_after=None,
              axis="Z", caps=True, closed=False):
        # Rings are (axial position, radius). Axis is local +Z.
        cx, cy, cz = at
        vertices = []
        for z, radius in rings:
            for i in range(sides):
                x, y = radius * cos(tau * i / sides), radius * sin(tau * i / sides)
                u, v, w = (z, x, y) if axis == "X" else (x, y, z)
                vertices.append((u + cx, v + cy, w + cz))
        offset = len(self.vertices)
        self.vertices.extend(vertices)
        if caps:
            self._face(tuple(offset + i for i in reversed(range(sides))), color, False)
        for row in range(len(rings) - (0 if closed else 1)):
            next_row = (row + 1) % len(rings)
            first, second = offset + row * sides, offset + next_row * sides
            normal_color = "dark" if inside_after is not None and row >= inside_after else color
            smooth = rings[row][0] != rings[next_row][0]
            for i in range(sides):
                j = (i + 1) % sides
                self._face((first + i, first + j, second + j, second + i), normal_color, smooth)
        if caps:
            last = offset + (len(rings) - 1) * sides
            self._face(tuple(last + i for i in range(sides)), "dark" if inside_after is not None else color, False)

    def _face(self, face, color, smooth):
        self.faces.append(face)
        self.face_materials.append(color)
        self.smooth.append(smooth)

    def data(self, name, materials):
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(self.vertices, [], self.faces)
        mesh.update()
        slots = {key: i for i, key in enumerate(dict.fromkeys(self.face_materials))}
        for key in slots:
            mesh.materials.append(materials[key])
        for face, color, smooth in zip(mesh.polygons, self.face_materials, self.smooth):
            face.material_index = slots[color]
            face.use_smooth = smooth
        return mesh


def from_rings(rings):
    """Closed loft whose rings run counter-clockwise viewed from above."""
    count = len(rings[0])
    vertices = [v for ring in rings for v in ring]
    faces = [tuple(reversed(range(count)))]
    for row in range(len(rings) - 1):
        start = row * count
        for i in range(count):
            j = (i + 1) % count
            faces.append((start + i, start + j, start + count + j, start + count + i))
    cap = (len(rings) - 1) * count
    faces.append(tuple(range(cap, cap + count)))
    return vertices, faces


def deck_ring(z, half, front, rear, corner):
    return [(x, y, z) for x, y in (
        (-half + corner, front), (half - corner, front), (half, front + corner),
        (half, rear - corner), (half - corner, rear), (-half + corner, rear),
        (-half, rear - corner), (-half, front + corner),
    )]


class Parts:
    def __init__(self, collection, parent, materials):
        self.collection = collection
        self.parent = parent
        self.materials = materials
        self.fasteners = {}

    def obj(self, name, mesh, at=(0, 0, 0), rotation=(0, 0, 0), bevel=0.0):
        obj = bpy.data.objects.new(name, mesh)
        self.collection.objects.link(obj)
        obj.parent = self.parent
        obj.location = at
        obj.rotation_euler = rotation
        if not mesh.uv_layers:
            project_uv(mesh, at)
        if bevel > 0.0:
            chamfer = obj.modifiers.new("Edge bevel", "BEVEL")
            chamfer.width = bevel
            chamfer.segments = 2
            chamfer.limit_method = "ANGLE"
            normal = obj.modifiers.new("Face normals", "WEIGHTED_NORMAL")
            normal.keep_sharp = True
        return obj

    def mesh(self, name, vertices, faces, color, bevel=0.0):
        parts = MeshParts()
        parts.add(vertices, faces, color)
        return self.obj(name, parts.data(name, self.materials), bevel=bevel)

    def loft(self, name, rings, color, bevel=0.0):
        return self.mesh(name, *from_rings(rings), color, bevel)

    def box(self, name, size, at, color, bevel=0.0, rotation=(0, 0, 0)):
        parts = MeshParts()
        parts.box(size, color=color)
        return self.obj(name, parts.data(name, self.materials), at, rotation, bevel)

    def cylinder(self, name, radius, length, at, color, rotation=(0, 0, 0), sides=24):
        parts = MeshParts()
        parts.lathe(((-length / 2, radius), (length / 2, radius)), sides, color)
        return self.obj(name, parts.data(name, self.materials), at, rotation)

    def beam(self, name, start, end, section, color, bevel=0.0):
        a, b = Vector(start), Vector(end)
        delta = b - a
        return self.box(name, (section[0], delta.length, section[1]), (a + b) / 2,
                        color, bevel, delta.to_track_quat("Y", "Z").to_euler())

    def pipe(self, name, points, radius, color, sides=10, pulse=0.0):
        points = [Vector(v) for v in points]
        if pulse:
            samples = []
            for a, b in zip(points, points[1:]):
                count = max(2, round((b - a).length / (pulse * 0.40)))
                samples.extend(a.lerp(b, i / count) for i in range(count))
            points = [*samples, points[-1]]
        rings = []
        distance = 0.0
        for i, p in enumerate(points):
            before, after = points[max(0, i - 1)], points[min(len(points) - 1, i + 1)]
            along = (after - before).normalized()
            ref = Vector((0, 0, 1)) if abs(along.z) < 0.88 else Vector((0, 1, 0))
            u = ref.cross(along).normalized()
            v = along.cross(u)
            if i > 0:
                distance += (p - points[i - 1]).length
            size = radius * (1 + 0.23 * sin(tau * distance / pulse)) if pulse else radius
            rings.append([tuple(p + size * (cos(tau * k / sides) * u + sin(tau * k / sides) * v))
                          for k in range(sides)])
        geometry = MeshParts()
        geometry.add(*from_rings(rings), color, True)
        return self.obj(name, geometry.data(name, self.materials))

    def ring(self, name, radius, thickness, at, color, rotation=(0, 0, 0)):
        sections, tube_sides = 20, 8
        rings = []
        for i in range(sections):
            angle = tau * i / sections
            rings.extend(((radius + thickness * cos(tau * j / tube_sides)) * cos(angle),
                          (radius + thickness * cos(tau * j / tube_sides)) * sin(angle),
                          thickness * sin(tau * j / tube_sides)) for j in range(tube_sides))
        faces = []
        for i in range(sections):
            a, b = i * tube_sides, ((i + 1) % sections) * tube_sides
            for j in range(tube_sides):
                k = (j + 1) % tube_sides
                faces.append((a + j, b + j, b + k, a + k))
        mesh = MeshParts()
        mesh.add(rings, faces, color, True)
        return self.obj(name, mesh.data(name, self.materials), at, rotation)


def from_side_plate(profile, x0, x1):
    # Winding is counterclockwise in the YZ plane, viewed along +X.
    area = sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(profile, profile[1:] + profile[:1]))
    if area < 0:
        profile = profile[::-1]
    return [[(x, y, z) for y, z in profile] for x in (x0, x1)]


def weld(p, name, a, b, radius=0.018):
    p.pipe(name, (a, b), radius, "weld", sides=8, pulse=0.026)


def flange_ring(p, name, radius, thickness, origin, color, rotation, count=32):
    mesh = MeshParts()
    mesh.lathe(((-thickness / 2, radius), (thickness / 2, radius),
                (thickness / 2, radius * 0.58), (-thickness / 2, radius * 0.58)),
               count, color, caps=False, closed=True)
    return p.obj(name, mesh.data(name, p.materials), origin, rotation)


def fastener(p, name, origin, rotation=(0, 0, 0), radius=0.031, color="olive"):
    unit = p.fasteners
    key = (radius, color)
    if key not in unit:
        mesh = MeshParts()
        mesh.lathe(((-radius * 0.42, radius * 1.26), (0.0, radius * 1.26),
                    (radius * 0.12, radius), (radius * 0.62, radius)),
                   12, "weld")
        mesh.lathe(((0.11 * radius, 0.9 * radius), (0.88 * radius, 0.9 * radius),
                    (1.06 * radius, 0.77 * radius)), 6, color)
        unit[key] = mesh.data(f"Washer and bolt {radius:.3f} {color}", p.materials)
    return p.obj(name, unit[key], origin, rotation)


def intake(p, name, x, y, width, length):
    z = D.hull_roof
    p.box(name + " dark recess", (width, length, 0.025), (x, y, z + 0.014), "dark", 0.01)
    for side in (-1, 1):
        p.box(name + f" longitudinal rim {side:+d}", (0.055, length + 0.05, 0.064),
              (x + side * width / 2, y, z + 0.047), "hull", 0.012)
        p.box(name + f" end rim {side:+d}", (width, 0.062, 0.067),
              (x, y + side * length / 2, z + 0.048), "hull", 0.012)
    slats = 10 if length > 0.8 else 7
    for i in range(slats):
        dy = (i + 1) * length / (slats + 1) - length / 2
        p.box(f"{name} louver {i + 1:02d}", (width - 0.074, 0.067, 0.042),
              (x, y + dy, z + 0.048), "olive", 0.005, (radians(23), 0, 0))
    p.box(name + " center brace", (0.035, length - 0.08, 0.036), (x, y, z + 0.078), "weld", 0.006)
    for sx in (-1, 1):
        for sy in (-1, 1):
            fastener(p, name + " frame attachment", (x + sx * width / 2, y + sy * (length / 2 - 0.045), z + 0.075), radius=0.020)


def build_hull(p):
    half_len = D.length / 2
    p.loft("01 · Belly pan and lower nose", [
        deck_ring(D.clearance, 0.78, -3.66, 4.13, 0.20),
        deck_ring(0.64, 0.86, -4.32, 4.38, 0.14),
        deck_ring(1.17, 1.18, -4.44, 4.45, 0.16),
        deck_ring(1.35, 1.25, -half_len, half_len, 0.17),
    ], "hull", 0.025)
    p.loft("02 · Welded upper hull and glacis", [
        deck_ring(1.145, 1.805, -4.38, 4.40, 0.16),
        deck_ring(1.365, 1.847, -half_len, half_len, 0.19),
        deck_ring(D.hull_roof, 1.746, -3.06, 3.97, 0.18),
    ], "hull", 0.025)
    p.cylinder("Turret race · recessed steel", 1.10, 0.16, (0, D.turret_y, 2.069), "dark", sides=68)
    for a in (i * tau / 24 for i in range(24)):
        fastener(p, "Turret race retaining bolt",
                 (1.025 * cos(a), D.turret_y + 1.025 * sin(a), 2.155), radius=0.021)

    side_profile = [(-4.33, 1.34), (-3.09, 2.065), (3.94, 2.065), (4.39, 1.40),
                    (4.26, 0.76), (3.98, 0.54), (-3.94, 0.54), (-4.27, 0.76)]
    for side, suffix in ((-1, "L"), (1, "R")):
        xs = sorted((side * 1.798, side * 1.849))
        p.loft(f"03 · Continuous deep side armor {suffix}", from_side_plate(side_profile, *xs),
               "hull", 0.020)
        x = side * 1.853
        for sign in (-1, 1):
            upper_y, lower_y = (-3.08, -4.28) if sign < 0 else (3.94, 4.33)
            weld(p, f"Armour seam {suffix} {sign:+d}", (x, upper_y, 2.02), (x, lower_y, 1.34), 0.016)
            p.pipe(f"Interlocking plate cut {suffix} {sign:+d}",
                   [(x, lower_y, 1.34), (x, lower_y - sign * 0.14, 1.26),
                    (x, lower_y - sign * 0.16, 1.13)], 0.009, "dark")
        p.pipe(f"Machined lower edge {suffix}", [(x, -3.94, 0.572), (x, 3.96, 0.572)], 0.013, "weld")
        for i, y in enumerate((-3.55, -2.14, -0.74, 0.70, 2.14, 3.54)):
            fastener(p, f"Side access retaining screw {suffix}.{i + 1}", (x, y, 0.65),
                     (0, side * pi / 2, 0), 0.029)
        # Engineering fittings sit on plates, with support tabs and deliberate spacing.
        p.box(f"Cable saddle backing {suffix}", (0.028, 2.77, 0.16), (x, 1.20, 1.561),
              "hull", 0.009)
        cable = [(side * 1.884, -0.54 + 0.12 * i, 1.65 - 0.14 * sin(pi * i / 28)) for i in range(29)]
        p.pipe(f"Flank tow cable {suffix}", cable, 0.024, "track", sides=9, pulse=0.027)
        for i, y in enumerate((0.09, 1.09, 2.30)):
            p.box(f"Cable retaining clamp {suffix}.{i + 1}", (0.044, 0.12, 0.075),
                  (side * 1.887, y, 1.544), "olive", 0.012)
            fastener(p, f"Cable clamp {suffix} fastener", (side * 1.911, y, 1.562),
                     (0, side * pi / 2, 0), 0.017)
        for y, tag in ((-0.62, "bow"), (2.91, "rear")):
            p.ring(f"Cable eye {suffix} {tag}", 0.067, 0.017, (side * 1.882, y, 1.638),
                   "track", ACROSS)

        # Low-profile glazed housings sit just above the glacis slope.
        lx = side * 1.23
        p.box(f"Glacis lamp foot {suffix}", (0.21, 0.27, 0.13), (lx, -3.82, 1.74), "olive",
              0.02, (radians(25), 0, 0))
        p.cylinder(f"Glacis headlamp body {suffix}", 0.105, 0.112, (lx, -3.90, 1.85), "dark", FRONT)
        p.cylinder(f"Glacis headlamp lens {suffix}", 0.083, 0.022, (lx, -3.963, 1.85), "lamp", FRONT)
        p.box(f"Headlamp blackout cover {suffix}", (0.16, 0.019, 0.056), (lx, -3.978, 1.87),
              "olive", 0.009)
        p.pipe(f"Lamp guard {suffix}", [(lx - 0.128, -3.88, 1.75), (lx - 0.13, -3.98, 1.93),
                                     (lx, -3.99, 1.982), (lx + 0.13, -3.98, 1.93),
                                     (lx + 0.128, -3.88, 1.75)], 0.013, "track")
        p.pipe(f"Lamp armored conduit {suffix}", [(lx + side * 0.09, -3.86, 1.79),
              (lx + side * 0.13, -3.69, 1.787), (lx + side * 0.10, -3.44, 1.924)], 0.012, "dark")

        hx = side * 0.64
        p.box(f"Driver hatch seat {suffix}", (0.66, 0.714, 0.028), (hx, -2.52, 2.093), "dark", 0.026)
        p.box(f"Flush deck hatch {suffix}", (0.619, 0.664, 0.051), (hx, -2.52, 2.122), "hull", 0.024)
        for u in (-0.181, 0.182):
            p.cylinder(f"Deck hatch hinge {suffix}", 0.041, 0.157, (hx + u, -2.233, 2.157),
                       "olive", ACROSS, 20)
        p.pipe(f"Deck hatch grab handle {suffix}", [(hx - 0.095, -2.70, 2.145),
            (hx - 0.085, -2.70, 2.202), (hx + 0.086, -2.70, 2.202),
            (hx + 0.095, -2.70, 2.145)], 0.013, "track")

        intake(p, f"Engine-air grille {suffix}", side * 0.80, 3.23, 0.96, 1.07)
        p.box(f"Rear glacis exhaust flange {suffix}", (0.28, 0.095, 0.24),
              (side * 0.94, 4.31, 1.65), "weld", 0.038, (radians(28), 0, 0))
        flange_ring(p, f"Rear exhaust nozzle {suffix}", 0.095, 0.11,
                    (side * 0.94, 4.378, 1.66), "exhaust", REAR, 28)
        p.cylinder(f"Rear exhaust darkness {suffix}", 0.061, 0.014,
                   (side * 0.94, 4.416, 1.66), "dark", REAR, 28)

    weld(p, "Front upper plate seam", (-1.65, -3.09, 2.083), (1.65, -3.09, 2.083), 0.014)
    weld(p, "Glacis-to-lower-plate weld", (-1.64, -4.478, 1.37), (1.64, -4.478, 1.37), 0.018)
    p.box("Forward recovery boss backing", (0.44, 0.14, 0.29), (0, -4.459, 0.989),
          "hull", 0.053, (radians(16), 0, 0))
    flange_ring(p, "Fore tow fitting", 0.118, 0.16, (0, -4.553, 0.986), "track",
                (radians(74), 0, 0), 32)
    for side in (-1, 1):
        x = side * 0.72
        p.loft(f"Lower bow recovery ear {side:+d}", from_side_plate(
            [(-4.49, 0.685), (-4.60, 0.728), (-4.57, 0.908), (-4.41, 1.07), (-4.24, 0.970)],
            x - 0.055, x + 0.055), "hull", 0.016)
        flange_ring(p, f"Lower bow lug eye {side:+d}", 0.084, 0.13,
                    (x, -4.56, 0.831), "track", ACROSS, 28)
        fastener(p, f"Lower glacis plate bolt {side:+d}", (side * 1.46, -4.46, 1.342), FRONT, 0.031)
        p.box(f"Glacis plate edge wedge {side:+d}", (0.102, 0.116, 0.157),
              (side * 1.55, -4.366, 1.226), "hull", 0.009, (radians(24), 0, 0))
    p.box("Driver visor backing plate", (0.59, 0.20, 0.153), (-0.26, -3.18, 2.019),
          "hull", 0.024, (radians(27), 0, 0))
    p.box("Driver visor armored brow", (0.47, 0.127, 0.128), (-0.26, -3.283, 2.086), "olive", 0.019)
    p.box("Driver visor slit", (0.33, 0.028, 0.028), (-0.26, -3.352, 2.073), "glass", 0.004)
    p.box("Engine center maintenance spine", (0.47, 1.17, 0.042), (0, 3.24, 2.105), "hull", 0.022)
    for y in (2.78, 3.12, 3.44, 3.72):
        fastener(p, "Engine spine retaining screw", (0, y, 2.128), radius=0.027)

    # The old rear had a broad, blank fascia. The lower center carries real geometry around the towing point.
    p.loft("Rear double towing shoe", [
        deck_ring(0.54, 0.63, 4.18, 4.49, 0.10),
        deck_ring(1.18, 0.73, 4.08, 4.516, 0.10),
    ], "hull", 0.025)
    p.box("Rear hitch anchor plate", (0.29, 0.125, 0.31), (0, 4.485, 0.943), "weld", 0.034)
    flange_ring(p, "Rear hitch forged eye", 0.116, 0.16, (0, 4.577, 0.967),
                "track", REAR, 32)
    for side in (-1, 1):
        x = side * 0.58
        p.beam(f"Rear towing shoe gusset {side:+d}", (x, 4.30, 1.11), (x, 4.58, 0.57),
               (0.128, 0.15), "olive", 0.021)
        flange_ring(p, f"Rear towing ear {side:+d}", 0.107, 0.112,
                    (x, 4.55, 0.70), "track", ACROSS, 28)
    weld(p, "Rear closing plate seam", (-1.64, 4.387, 1.37), (1.64, 4.387, 1.37), 0.015)
    for x in (-1.26, -0.84, -0.42, 0.42, 0.84, 1.26):
        fastener(p, "Rear plate retaining bolt", (x, 4.433, 1.383), REAR, 0.037)
    p.box("Rear convoy light bracket", (0.27, 0.12, 0.14), (-0.23, 4.17, 1.82), "olive", 0.021)
    p.box("Rear convoy lamp", (0.105, 0.025, 0.067), (-0.23, 4.24, 1.82), "amber", 0.010)


def turret_ring(z, w, nose, tail):
    # A rolled bow and broad planar sides narrowing toward the roof.
    return [(x * w, y, z) for x, y in (
        (-0.55, nose), (0.0, nose - 0.029), (0.55, nose),
        (0.79, nose + 0.095), (0.94, nose + 0.246), (1.0, nose + 0.44),
        (1.0, tail - 0.17), (0.91, tail), (-0.91, tail),
        (-1.0, tail - 0.17), (-1.0, nose + 0.44), (-0.94, nose + 0.246),
        (-0.79, nose + 0.095),
    )]


def build_turret(p, gun, socket_collection):
    rings = [turret_ring(z, w, front, rear) for z, w, front, rear in (
        (0.065, 1.295, -1.34, 1.55),
        (0.175, 1.425, -1.60, 1.825),
        (0.34, 1.380, -1.747, 1.773),
        (0.56, 1.318, -1.815, 1.701),
        (0.80, 1.251, -1.760, 1.622),
        (1.04, 1.184, -1.578, 1.545),
        (D.turret_height, 1.121, -1.351, 1.497),
    )]
    body = p.loft("Turret · rolled bow, pitched cheeks and rear armor", rings, "turret", 0.027)
    for face in body.data.polygons[1:-1]:
        face.use_smooth = (face.index - 1) % len(rings[0]) in (0, 1, 2, 3, 4, 10, 11, 12)
    h = D.turret_height

    # A narrow weld follows the roof-to-side join instead of rounding out the silhouette.
    for side, name in ((-1, "L"), (1, "R")):
        weld(p, f"Turret roof seam {name}", (side * 1.112, -0.90, h + 0.001),
             (side * 1.112, 1.30, h + 0.001), 0.011)
        p.pipe(f"Turret rear corner weld {name}", [(side * w * 0.932, rear - 0.026, z) for z, w, rear in
               ((0.195, 1.419, 1.822), (0.56, 1.318, 1.701), (0.98, 1.202, 1.565), (1.13, 1.137, 1.514))],
               0.013, "weld", pulse=0.019)
        p.box(f"Turret lifting-lug foot {name}", (0.18, 0.13, 0.046), (side * 0.91, 0.97, h + 0.023),
              "turret", 0.012)
        p.ring(f"Turret lifting eye {name}", 0.064, 0.019, (side * 0.91, 0.97, h + 0.08),
               "track", FRONT)

    covers = [(-0.47, 0.32, 0.343, "Gunner"), (0.48, 0.46, 0.38, "Commander")]
    for x, y, r, label in covers:
        p.cylinder(f"{label} roof hatch gasket", r + 0.02, 0.027, (x, y, h + 0.022), "dark", sides=40)
        p.cylinder(f"{label} low hatch cover", r, 0.061, (x, y, h + 0.057), "turret", sides=40)
        p.box(f"{label} hatch hinge block", (0.26, 0.10, 0.065), (x, y + r * 0.88, h + 0.094),
              "olive", 0.019)
        p.cylinder(f"{label} hatch hinge pin", 0.034, 0.261, (x, y + r * 0.88, h + 0.114),
                   "track", ACROSS, 20)
        p.pipe(f"{label} hatch handgrip", [(x - 0.1, y - 0.12, h + 0.083), (x - 0.092, y - 0.12, h + 0.131),
                (x + 0.09, y - 0.12, h + 0.131), (x + 0.1, y - 0.12, h + 0.083)],
               0.012, "track")
        p.box(f"{label} periscope guard", (0.24, 0.205, 0.11), (x, y - r - 0.08, h + 0.057),
              "turret", 0.024)
        p.box(f"{label} viewing slit", (0.188, 0.019, 0.048), (x, y - r - 0.188, h + 0.061),
              "glass", 0.004)
    p.cylinder("Recessed turret ventilator", 0.184, 0.047, (0.0, -0.47, h + 0.034), "weld", sides=32)
    p.cylinder("Ventilator domed cover", 0.147, 0.054, (0.0, -0.47, h + 0.079), "olive", sides=32)
    p.cylinder("Antenna protective boss", 0.070, 0.104, (-0.74, 1.17, h + 0.062), "olive", sides=16)
    p.pipe("Radio antenna", [(-0.74, 1.17, h + 0.102), (-0.77, 1.184, h + 0.448),
                            (-0.83, 1.22, h + 0.89)], 0.008, "dark", sides=8)

    # The survivor's rear turret plate has a central cover with two grasping loops.
    rear_z, rear_y = 0.655, 1.695
    p.cylinder("Rear turret plug collar", 0.174, 0.073, (0, rear_y, rear_z), "turret",
               (radians(-73), 0, 0), 40)
    flange_ring(p, "Rear turret plug handwheel shoulder", 0.134, 0.081,
                (0, rear_y + 0.057, rear_z), "olive", (radians(-73), 0, 0), 36)
    p.cylinder("Rear turret plug recess", 0.074, 0.023, (0, rear_y + 0.098, rear_z), "dark",
               (radians(-73), 0, 0), 32)
    for side in (-1, 1):
        p.pipe(f"Turret cover grab ear {side:+d}", [(side * 0.096, rear_y + 0.033, rear_z + 0.11),
              (side * 0.149, rear_y + 0.043, rear_z + 0.187),
              (side * 0.203, rear_y + 0.008, rear_z + 0.174),
              (side * 0.167, rear_y + 0.026, rear_z + 0.11)], 0.016, "track", sides=12)
    for i in range(10):
        p.ring(f"Rear plug retainer link {i + 1:02d}", 0.023, 0.0065,
               (0.01 * sin(i * 0.73), rear_y + 0.10 + i * 0.005, rear_z - 0.139 - i * 0.037),
               "track", (pi / 2, 0, pi / 2 * (i % 2)))

    # External visible cradle and barrels follow the existing pitch pivot.
    gun.loft("Asymmetric cast gun cradle", [
        deck_ring(-0.43, 0.68, -0.233, 0.09, 0.12),
        deck_ring(-0.28, 0.88, -0.453, 0.11, 0.16),
        deck_ring(0.10, 0.91, -0.533, 0.12, 0.17),
        deck_ring(0.43, 0.82, -0.296, 0.09, 0.15),
    ], "turret", 0.035)
    sleeve = MeshParts()
    sleeve.lathe(((0.27, 0.235), (0.41, 0.305), (0.68, 0.271),
                  (0.93, 0.219), (1.03, 0.207)), 48, "turret")
    gun.obj("Bolstered barrel collar", sleeve.data("Gun collar", gun.materials), rotation=FRONT)
    barrel = MeshParts()
    barrel.lathe(((0.59, 0.174), (0.99, 0.171), (1.20, 0.146), (1.39, 0.141),
                  (3.72, 0.108), (4.19, 0.107), (4.264, 0.115),
                  (D.barrel_length, 0.114), (D.barrel_length, 0.050), (4.13, 0.050)),
                 52, "turret", inside_after=8)
    gun.obj("Main gun exterior", barrel.data("Main gun exterior", gun.materials), rotation=FRONT)
    # Small coaxial tube retained as a silhouette detail of the Maus turret.
    coax = MeshParts()
    coax.lathe(((0.26, 0.106), (0.56, 0.105), (0.69, 0.068), (1.36, 0.052),
                (1.40, 0.052), (1.40, 0.031), (1.31, 0.031)),
               36, "turret", inside_after=5)
    gun.obj("Coaxial exterior tube", coax.data("Coaxial exterior tube", gun.materials),
            (0.614, -0.019, -0.082), FRONT)
    gun.cylinder("Gunner sight collar", 0.073, 0.111, (-0.61, -0.474, 0.165), "weld", FRONT, 28)
    gun.cylinder("Gunner sight glass", 0.037, 0.018, (-0.61, -0.538, 0.167), "glass", FRONT, 28)
    for x, z in ((0.712, 0.217), (-0.43, -0.213), (0.274, -0.229)):
        fastener(gun, "Cast cradle retaining hardware", (x, -0.477, z), FRONT, 0.041)
    socket = pivot("MUZZLE_SOCKET", socket_collection, gun.parent, (0, -D.barrel_length, 0), 0.13)
    socket["axis"] = "-Y forward."


def track_path(distance, axle, radius, height):
    straight = 2 * axle
    arc = pi * radius
    if distance < straight:
        return -axle + distance, height - radius, 0.0
    distance -= straight
    if distance < arc:
        angle = distance / radius - pi / 2
        return axle + radius * cos(angle), height + radius * sin(angle), angle + pi / 2
    distance -= arc
    if distance < straight:
        return axle - distance, height + radius, pi
    angle = (distance - straight) / radius + pi / 2
    return -axle + radius * cos(angle), height + radius * sin(angle), angle + pi / 2


def shoe_mesh(pitch, materials, connector):
    shoe = MeshParts()
    if connector:
        # The narrow connector has genuine openings between its guides.
        for x in (-0.345, -0.134, 0.134, 0.345):
            shoe.box((0.091, pitch * 0.94, 0.062), (x, 0, 0.002), "track")
            shoe.box((0.072, pitch * 0.35, 0.029), (x, 0.025, -0.034), "polished")
        shoe.box((0.846, pitch * 0.21, 0.073), (0, -pitch * 0.27, 0.015), "track")
        shoe.box((0.846, pitch * 0.19, 0.070), (0, pitch * 0.27, 0.018), "track")
    else:
        # Hollow box sections flank each shoe's integral two contact ribs.
        shoe.box((0.962, pitch * 0.86, 0.038), (0, 0, 0.005), "track")
        for x in (-0.345, 0.345):
            shoe.box((0.21, pitch * 0.77, 0.041), (x, 0, -0.026), "track")
        for y in (-pitch * 0.22, pitch * 0.22):
            shoe.box((0.885, pitch * 0.17, 0.023), (0, y, -0.041), "polished")
        for x in (-0.271, 0, 0.271):
            shoe.box((0.036, pitch * 0.68, 0.032), (x, 0, 0.029), "track")
    for side in (-1, 1):
        x = side * (0.446 if connector else 0.459)
        for y in (-pitch * 0.34, pitch * 0.34):
            shoe.lathe(((-0.024, 0.027), (0.024, 0.027)), 9, "track", (x, y, 0.018), axis="X")
            shoe.lathe(((-0.011, 0.017), (0.011, 0.017)), 7, "polished",
                       (x + side * 0.016, y, 0.018), axis="X")
        shoe.box((0.073, pitch * 0.36, 0.071), (side * 0.139, -0.005, 0.055), "track")
        tip = MeshParts()
        tip.box((0.054, pitch * 0.24, 0.025), (side * 0.139, -0.005, 0.099), "weld")
        shoe.add(tip.vertices, tip.faces, "weld")
    kind = "Connector" if connector else "Contact shoe"
    return shoe.data(f"Linked track · {kind}", materials)


def wheel_mesh(name, radius, width, materials, drive=False, idler=False):
    wheel = MeshParts()
    wheel.lathe(((-width * 0.56, radius * 0.86),
                 (-width * 0.47, radius * 0.94), (-width * 0.37, radius),
                 (width * 0.36, radius), (width * 0.49, radius * 0.97),
                 (width * 0.55, radius * 0.90)), 36, "track")
    wheel.lathe(((width * 0.50, radius * 0.88), (width * 0.55, radius * 0.87),
                 (width * 0.62, radius * 0.78), (width * 0.53, radius * 0.56),
                 (width * 0.57, radius * 0.43)), 36, "olive")
    wheel.lathe(((width * 0.57, radius * 0.47), (width * 0.66, radius * 0.47),
                 (width * 0.73, radius * 0.36), (width * 0.78, radius * 0.30)), 26, "weld")
    for i in range(10 if drive or idler else 6):
        a = tau * i / (10 if drive or idler else 6)
        r = radius * 0.55
        x, y = r * cos(a), r * sin(a)
        wheel.lathe(((-0.012, 0.017), (0.012, 0.017)), 6, "polished", (x, y, width * 0.61))
    if drive:
        for i in range(18):
            a = tau * i / 18
            c, s = cos(a), sin(a)
            for z in (-width * 0.39, width * 0.39):
                blank = MeshParts()
                blank.box((radius * 0.25, radius * 0.14, width * 0.23), (radius * 0.94, 0, z), "track")
                wheel.add([(c * x - s * y, s * x + c * y, z) for x, y, z in blank.vertices], blank.faces, "track")
    return wheel.data(name, materials)


def build_running_gear(gear_collection, hull, materials):
    axle, radius, height = 3.91, 0.499, 0.554
    perimeter = 4 * axle + tau * radius
    count = 96
    pitch = perimeter / count
    shoes = [shoe_mesh(pitch, materials, connector=False), shoe_mesh(pitch, materials, connector=True)]
    road = wheel_mesh("Steel-rim road wheel", 0.242, 0.192, materials)
    roller = wheel_mesh("Return roller", 0.127, 0.19, materials)
    idler = wheel_mesh("Pitched front track idler", 0.454, 0.645, materials, idler=True)
    drive = wheel_mesh("Twin-row rear sprocket", 0.456, 0.684, materials, drive=True)
    x = (D.width - D.track_width) / 2
    for side, suffix in ((-1, "L"), (1, "R")):
        group = child_collection(suffix + " · track and wheels", gear_collection)
        track = pivot(f"TRACK_{suffix}", group, hull, (side * x, 0, 0))
        track["shoe_count"] = count
        belt = Parts(group, track, materials)
        for i in range(count):
            y, z, tilt = track_path(i * pitch, axle, radius, height)
            belt.obj(f"Shoe_{suffix}_{i + 1:03d}", shoes[i % 2], (0, y, z), (tilt, 0, 0))
        wheel_rotation = (0, side * pi / 2, 0)
        belt.obj(f"Front_Idler_{suffix}", idler, (0, -axle, height), wheel_rotation)
        belt.obj(f"Rear_Sprocket_{suffix}", drive, (0, axle, height), wheel_rotation)
        for i in range(6):
            y = -2.98 + i * 1.19
            mount = pivot(f"BOGIE_{suffix}_{i + 1:02d}", group, track, (0, y, 0.0))
            p = Parts(group, mount, materials)
            p.box("Suspension carrier", (0.55, 0.75, 0.25), (-side * 0.018, 0, 0.621), "olive", 0.028)
            p.obj("Return roller", roller, (side * 0.21, 0.04, 0.856), wheel_rotation)
            for station, offset in enumerate((-0.269, 0.269)):
                for wheel_side in (-1, 1):
                    wx = side * (wheel_side * 0.242 + 0.020 * (station * 2 - 1))
                    p.obj(f"Paired road wheel {station + 1}.{wheel_side:+d}", road,
                          (wx, offset, 0.333), wheel_rotation)
                p.cylinder("Cross-axle", 0.076, 0.51, (0, offset, 0.335), "dark", ACROSS, 16)


def moldboard(parts):
    width = D.width + 0.36
    rows, cols = 17, 19
    # The curved working face turns forward along both wing edges.
    heights = [-0.42 + 0.85 * i / (rows - 1) for i in range(rows)]
    columns = [-1.0 + 2.0 * i / (cols - 1) for i in range(cols)]
    def skin(u, z, thickness=0.0):
        t = (z + 0.42) / 0.85
        return (u * width / 2,
                -0.189 + 0.35 * sin(pi * t) + 0.109 * t
                - 0.197 * (max(0, abs(u) - 0.70) / 0.30) ** 1.6 + thickness,
                z - 0.041 * max(0, abs(u) - 0.85) / 0.15)
    verts = [skin(u, z, t) for t in (0.0, 0.109) for z in heights for u in columns]
    offset = rows * cols
    faces = []
    for r in range(rows - 1):
        for c in range(cols - 1):
            a = r * cols + c
            quad = (a, a + 1, a + cols + 1, a + cols)
            faces.extend((quad, tuple(i + offset for i in reversed(quad))))
    bounds = list(range(cols))
    bounds += [r * cols + cols - 1 for r in range(1, rows)]
    bounds += list(range(offset - 2, offset - cols - 1, -1))
    bounds += [r * cols for r in range(rows - 2, 0, -1)]
    for i, a in enumerate(bounds):
        b = bounds[(i + 1) % len(bounds)]
        faces.append((b, a, a + offset, b + offset))
    shell = parts.mesh("Continuous curved moldboard shell", verts, faces, "blade", 0.010)
    for face in shell.data.polygons[: 2 * (rows - 1) * (cols - 1)]:
        face.use_smooth = True
    for i, (u, v) in enumerate(zip(columns, columns[1:]), 1):
        a, b = Vector(skin(u, -0.402, -0.058)), Vector(skin(v, -0.402, -0.058))
        if i % 3 == 1:
            a = a.lerp(b, 0.035)
        parts.beam(f"Hardened cutting edge {i:02d}", a, b, (0.102, 0.082), "polished", 0.006)
        if i % 2:
            pin = (a + b) / 2
            pin.y -= 0.058
            fastener(parts, f"Cutting edge hex bolt {i:02d}", pin, FRONT, 0.029, "track")
    # Real rear volume of the blade, with contours tracing its back face.
    for u in (-0.76, -0.56, -0.29, 0, 0.29, 0.56, 0.76):
        zs = heights[2:-2]
        section = [(skin(u, z, 0.10)[1], z) for z in reversed(zs)]
        section += [(skin(u, z, 0.28)[1], z) for z in zs]
        x = u * width / 2
        parts.loft(f"Moldboard rear gusset {x:+.2f}", from_side_plate(section, x - 0.045, x + 0.045),
                   "olive", 0.012)
    for side in (-1, 1):
        x = side * 1.99
        cheek = [(-0.388, -0.402), (-0.53, -0.37), (-0.47, 0.12),
                 (-0.19, 0.385), (0.017, 0.326), (0.007, -0.24)]
        parts.loft(f"Moldboard outer cheek {side:+d}", from_side_plate(cheek, x - 0.028, x + 0.028),
                   "track", 0.014)
    for z in (-0.19, 0.238):
        parts.beam("Rear reinforcing crossrail", (-1.68, 0.365, z), (1.68, 0.365, z),
                   (0.124, 0.12), "olive", 0.024)


def build_blade(scene, collection, hull, materials):
    lift = pivot("DOZER_LIFT_PIVOT", collection, hull, (0, -3.47, 0.65), 0.26)
    lift["channel"] = "Rotate on local X to lift the full linkage."
    blade = pivot("BLADE_PIVOT", collection, lift, (0, -1.54, 0), 0.23)
    blade.rotation_euler.x = 0.031
    blade["channel"] = "Local X controls the moldboard pitch."
    fixed = Parts(collection, hull, materials)
    linkage = Parts(collection, lift, materials)
    plow = Parts(collection, blade, materials)
    moldboard(plow)

    for side, suffix in ((-1, "L"), (1, "R")):
        x = side * 1.33
        fixed.box(f"Dozer chassis bracket {suffix}", (0.38, 0.54, 0.48), (x, -3.45, 0.84),
                  "hull", 0.044)
        fixed.cylinder(f"Dozer chassis hinge pin {suffix}", 0.104, 0.43, (x, -3.47, 0.65),
                       "polished", ACROSS, 24)
        for z in (0.72, 0.96):
            fastener(fixed, f"Dozer mounting plate studs {suffix}", (x + side * 0.20, -3.43, z),
                     (0, side * pi / 2, 0), 0.031)
        p0 = (x - side * 0.14, -3.52, 0.72)
        p1 = (x - side * 0.14, -3.39, 1.03)
        weld(fixed, f"Load spreader weld {suffix}", p0, p1, 0.018)
        linkage.beam(f"Armoured push arm {suffix}", (x, 0.01, 0.0), (side * 1.23, -1.19, -0.09),
                     (0.22, 0.24), "olive", 0.039)
        plow.box(f"Blade rear arm saddle {suffix}", (0.25, 0.216, 0.22),
                 (side * 1.23, 0.349, -0.09), "blade", 0.038)

        # The rod reaches the blade anchor and slides under the rigid ram body.
        pin_x = side * 1.48
        anchor = pivot(f"DOZER_RAM_END_{suffix}", collection, blade, (pin_x, 0.33, 0.13), 0.09)
        plow.cylinder(f"Moldboard ram pin {suffix}", 0.054, 0.20, (pin_x, 0.33, 0.13),
                      "polished", ACROSS, 14)
        housing = pivot(f"DOZER_RAM_BASE_{suffix}", collection, hull, (pin_x, -3.72, 1.48), 0.11)
        aim = housing.constraints.new("DAMPED_TRACK")
        aim.target = anchor
        aim.track_axis = "TRACK_Y"
        fixed.box(f"Ram chassis clevis {suffix}", (0.24, 0.18, 0.22),
                  (pin_x, -3.67, 1.48), "olive", 0.028)
        tube = Parts(collection, housing, materials)
        tube.cylinder(f"Hydraulic cylinder {suffix}", 0.093, 0.70, (0, 0.36, 0), "olive", REAR)
        tube.cylinder(f"Cylinder gland {suffix}", 0.104, 0.073, (0, 0.69, 0), "dark", REAR)
        tube.cylinder(f"Rod wiper lip {suffix}", 0.060, 0.027, (0, 0.732, 0), "rubber", REAR, 24)
        for y in (0.149, 0.575):
            tube.cylinder(f"Hydraulic cylinder collar {suffix}", 0.108, 0.046, (0, y, 0), "weld", REAR)
        hs = side * 0.118
        hose = [(0.0, 0.017, 0.052), (hs * 0.62, 0.053, 0.104), (hs, 0.105, 0.103),
                (hs, 0.194, 0.078), (hs * 0.80, 0.279, 0.026)]
        tube.pipe(f"Ram hose {suffix}", hose, 0.021, "rubber", sides=12)
        tube.pipe(f"Ram return hose {suffix}", [(a * 0.89, b + 0.033, c + 0.032) for a, b, c in hose],
                  0.018, "rubber", sides=12)
        tube.box(f"Hose gland retaining block {suffix}", (0.105, 0.073, 0.078),
                 (hs * 0.72, 0.285, 0.028), "olive", 0.012)
        rod_geometry = MeshParts()
        rod_geometry.lathe(((0.0, 0.049), (1.0, 0.049)), 20, "polished")
        rod = fixed.obj(f"Hydraulic piston rod {suffix}",
                        rod_geometry.data(f"Piston rod {suffix}", materials), housing.location)
        # Local +Y is the stretch axis. Keep the geometry as an editable mesh.
        rod.data.transform(REAR_MATRIX)
        constraint = rod.constraints.new("STRETCH_TO")
        constraint.target = anchor
        constraint.rest_length = 1.0
        constraint.volume = "NO_VOLUME"

    for frame, angle in ((FRAME_TRAVEL, -21.75), (FRAME_WORK, 6.30)):
        lift.rotation_euler.x = radians(angle)
        lift.keyframe_insert(data_path="rotation_euler", index=0, frame=frame)
    scene.frame_start, scene.frame_end = FRAME_TRAVEL, FRAME_WORK
    scene.timeline_markers.new("Blade raised", frame=FRAME_TRAVEL)
    scene.timeline_markers.new("Blade lowered", frame=FRAME_WORK)


def lighting(scene):
    studio = child_collection("Studio · camera and lights", scene.collection)
    floor_mat = material("Studio floor | slate", "32383D", 0.75, 0.0, 0.05)
    floor = Parts(studio, None, {"floor": floor_mat})
    floor.box("Studio ground", (1600.0, 1600.0, 0.12), (0, 0, -0.066), "floor")

    def aim(obj, target):
        obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()

    def area(name, at, target, power, size, color):
        data = bpy.data.lights.new(name, "AREA")
        data.energy, data.size, data.color = power, size, color
        obj = bpy.data.objects.new(name, data)
        studio.objects.link(obj)
        obj.location = at
        aim(obj, target)

    area("Key · soft warm light", (4, -6.8, 9.2), (0, -1, 1), 3000, 7.5, (1.0, 0.94, 0.84))
    area("Fill · blue-grey", (-7, -4, 5), (0, 0, 1), 1200, 6.5, (0.80, 0.89, 1.0))
    area("Rim · deck", (1, 7, 7.7), (0, 1, 1), 2920, 5.4, (0.92, 0.95, 1.0))

    data = bpy.data.cameras.new("Engineering three-quarter")
    camera = bpy.data.objects.new("Engineering three-quarter", data)
    studio.objects.link(camera)
    camera.location = (11.5, -15.1, 6.9)
    aim(camera, (0.12, -0.78, 1.38))
    data.lens = 58
    scene.camera = camera

    world = bpy.data.worlds.new("Maus Studio")
    world.use_nodes = True
    world.node_tree.nodes.get("Background").inputs[0].default_value = (0.115, 0.14, 0.17, 1.0)
    world.node_tree.nodes.get("Background").inputs[1].default_value = 0.45
    scene.world = world
    scene.render.resolution_x, scene.render.resolution_y = 1600, 1000
    scene.render.resolution_percentage = 100
    scene.view_settings.view_transform = "AgX" if bpy.app.version >= (4, 0, 0) else "Filmic"
    return studio


def present(scene):
    window = bpy.context.window
    if window is None:
        return
    window.scene = scene
    camera = scene.camera
    if camera is None:
        return
    for area in window.screen.areas:
        if area.type == "VIEW_3D":
            space = area.spaces.active
            space.region_3d.view_rotation = camera.rotation_euler.to_quaternion()
            space.region_3d.view_location = Vector((0, -0.62, 1.20))
            space.region_3d.view_distance = 15.0
            space.region_3d.view_perspective = "PERSP"
            space.shading.color_type = "MATERIAL"
            space.overlay.show_extras = False


def build_scene():
    # Reopening the script focuses the existing generated scene. User edits are kept.
    existing = next((s for s in bpy.data.scenes if s.get(SCENE_KEY) == 1), None)
    if existing:
        present(existing)
        return existing

    scene = bpy.data.scenes.new(SCENE_NAME)
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.length_unit = "METERS"
    asset = child_collection("Maus_Engineering · vehicle asset", scene.collection)
    hull_collection = child_collection("01 · Hull", asset)
    turret_collection = child_collection("02 · Turret and gun", asset)
    gear_collection = child_collection("03 · Running gear", asset)
    blade_collection = child_collection("04 · Dozer assembly", asset)

    root = pivot("MAUS_ENG_ROOT", asset, size=0.45)
    root["vehicle_id"] = "mauseng"
    root["scale"] = "1 Blender unit = 1 m"
    root["orientation"] = "-Y forward, +Z up, origin at ground centre"
    root["hull_length_m"] = D.length
    root["hull_width_m"] = D.width
    hull = pivot("HULL", hull_collection, root)
    turret = pivot("TURRET_PIVOT", turret_collection, hull, (0, D.turret_y, D.hull_roof))
    turret["channel"] = "Local Z rotates the turret."
    gun = pivot("GUN_PIVOT", turret_collection, turret,
                (0, -D.turret_length * 0.43, D.turret_height * 0.44))
    gun["channel"] = "Local X controls elevation."

    mats = make_materials()
    apply_material_maps(mats)
    build_hull(Parts(hull_collection, hull, mats))
    build_turret(Parts(turret_collection, turret, mats), Parts(turret_collection, gun, mats), turret_collection)
    build_running_gear(gear_collection, hull, mats)
    build_blade(scene, blade_collection, hull, mats)
    studio = lighting(scene)

    present(scene)
    view_layer = scene.view_layers[0]
    for obj in studio.objects:
        obj.hide_set(True, view_layer=view_layer)
    root.select_set(True, view_layer=view_layer)
    view_layer.objects.active = root
    scene.frame_set(FRAME_TRAVEL)
    scene[SCENE_KEY] = 1
    print("Maus Engineering: model ready. Frame 1 raised; frame 36 lowered.")
    return scene


if __name__ == "__main__":
    build_scene()
