@echo off
setlocal
cd /d "%~dp0"
set "BLENDER="
if defined BLENDER_EXE if exist "%BLENDER_EXE%" set "BLENDER=%BLENDER_EXE%"
if not defined BLENDER for /f "delims=" %%B in ('where.exe blender.exe 2^>nul') do if not defined BLENDER set "BLENDER=%%B"
if not defined BLENDER call :find_blender "%ProgramFiles%\Blender Foundation"
if not defined BLENDER call :find_blender "%ProgramW6432%\Blender Foundation"
if not defined BLENDER call :find_blender "%LocalAppData%\Programs\Blender Foundation"
if not defined BLENDER (
    echo [ERROR] Blender 4.2 or later was not found.
    echo Install Blender or set BLENDER_EXE to the full path of blender.exe.
    pause
    exit /b 1
)

"%BLENDER%" --background --factory-startup --python-exit-code 1 --python "%~dp0build_maus.py" -- %*
set "RESULT=%errorlevel%"
if not "%RESULT%"=="0" (
    echo [ERROR] The model could not be generated. Details are above.
) else (
    echo Model generated. Check the output folder next to this file.
)
pause
exit /b %RESULT%

:find_blender
if not exist "%~1" exit /b 0
for /f "delims=" %%D in ('dir /b /ad /o-n "%~1\Blender*" 2^>nul') do if not defined BLENDER if exist "%~1\%%D\blender.exe" set "BLENDER=%~1\%%D\blender.exe"
exit /b 0
