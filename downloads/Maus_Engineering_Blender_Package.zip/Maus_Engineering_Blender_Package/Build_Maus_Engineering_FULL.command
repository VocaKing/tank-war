#!/bin/bash
exec "$(dirname -- "$0")/Build_Maus_Engineering.command" --full
