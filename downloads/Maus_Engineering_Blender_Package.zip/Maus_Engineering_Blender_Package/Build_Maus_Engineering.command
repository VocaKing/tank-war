#!/bin/bash
set -u
cd -P -- "$(dirname -- "$0")" || exit 1
blender=""
for candidate in "${BLENDER_EXE:-}" "/Applications/Blender.app/Contents/MacOS/Blender" "$HOME/Applications/Blender.app/Contents/MacOS/Blender"; do
    if [ -x "$candidate" ]; then
        blender="$candidate"
        break
    fi
done
if [ -z "$blender" ]; then
    blender="$(command -v blender || true)"
fi
if [ -z "$blender" ]; then
    printf '%s\n' '需要 Blender 4.2 或更新版本。请将 Blender.app 安装到 Applications。' >&2
    exit 1
fi
"$blender" --background --factory-startup --python-exit-code 1 --python "$PWD/build_maus.py" -- "$@"
result=$?
if [ "$result" -eq 0 ]; then
    printf '%s\n' '模型已生成。请查看同一文件夹下的 output。'
fi
exit "$result"
