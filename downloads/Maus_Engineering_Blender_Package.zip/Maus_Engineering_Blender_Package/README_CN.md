# 鼠式工程型超重型坦克 · 一键建模包

解压整个 ZIP，双击与你系统对应的启动文件。启动器会使用已经安装的 Blender 4.2 或更新版本在后台生成模型。全过程在终端窗口里完成。

| 系统 | 快速生成 | 同时生成五视角渲染 |
| --- | --- | --- |
| Windows | `Build_Maus_Engineering.cmd` | `Build_Maus_Engineering_FULL.cmd` |
| macOS | `Build_Maus_Engineering.command` | `Build_Maus_Engineering_FULL.command` |

生成结果在同一文件夹下的 `output/Maus_Engineering/`。再次生成会写入新的编号文件夹。

- **Maus_Engineering.blend** 保存可编辑模型、迷彩材质、分部件轴点和推土铲动画。第 1 帧抬铲，第 36 帧放铲。修改好后可以把这个文件发回来。
- **Maus_Engineering.glb** 是车体模型的游戏预览导出，包含推土铲动画。程序化迷彩保存在 .blend 里，GLB 使用基础颜色和金属材质。
- **FULL** 额外生成前斜、左侧、正面、车尾和顶视角的 PNG。渲染时间由电脑性能决定。

Windows 启动器会查找 PATH 和 Blender 的常见安装目录。macOS 默认查找 Applications 里的 Blender.app。自定义安装路径可通过 `BLENDER_EXE` 指定 Blender 可执行文件。
