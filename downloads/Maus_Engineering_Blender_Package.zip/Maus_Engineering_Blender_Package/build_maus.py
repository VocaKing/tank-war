"""Build the editable project and game export from Blender's background CLI."""

import argparse
from itertools import count
from pathlib import Path
import runpy
import sys
from tempfile import TemporaryDirectory

import bpy
from mathutils import Vector


PACKAGE = Path(__file__).resolve().parent
NAME = "Maus_Engineering"


def save_model(scene, folder):
    scene.frame_set(1)
    bpy.ops.wm.save_as_mainfile(filepath=str(folder / (NAME + ".blend")), compress=True)

    root = scene.objects["MAUS_ENG_ROOT"]
    for obj in scene.view_layers[0].objects:
        obj.select_set(False)
    for obj in [root, *root.children_recursive]:
        obj.select_set(True)
    scene.view_layers[0].objects.active = root
    bpy.ops.export_scene.gltf(
        filepath=str(folder / (NAME + ".glb")),
        export_format="GLB",
        use_selection=True,
        export_apply=True,
        export_extras=True,
        export_yup=True,
        export_animations=True,
        export_animation_mode="SCENE",
        export_frame_range=True,
    )


def render_views(scene, folder):
    camera = scene.camera
    scene.frame_set(36)
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = 20
    scene.cycles.use_denoising = False
    scene.render.resolution_x = 840
    scene.render.resolution_y = 560
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"

    for view, at in (
        ("front3q", None),
        ("left", (-16, -0.65, 2.65)),
        ("front", (0, -18, 2.65)),
        ("rear", (0, 17, 3.15)),
        ("top", (0, -0.62, 18)),
    ):
        if at:
            camera.data.type = "ORTHO"
            camera.data.ortho_scale = 12.5 if view != "top" else 18
            camera.location = at
            camera.rotation_euler = (Vector((0, -0.62, 1.25)) - camera.location).to_track_quat("-Z", "Y").to_euler()
        scene.render.filepath = str(folder / f"render_{view}.png")
        bpy.ops.render.render(write_still=True)


def publish_build(staging, output):
    # A later run leaves previous .blend edits intact.
    for n in count(1):
        destination = output / (NAME if n == 1 else f"{NAME}_{n:02d}")
        if destination.exists():
            continue
        try:
            return staging.rename(destination)
        except OSError:
            if not destination.exists():
                raise


def main():
    if not bpy.app.background or bpy.app.version < (4, 2, 0):
        raise RuntimeError("Run this launcher with Blender 4.2 or later in background mode.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--full", action="store_true", help="also render five PNG views")
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else [])

    scene = runpy.run_path(str(PACKAGE / "Maus_Engineering_Model.py"))["build_scene"]()
    for factory_scene in list(bpy.data.scenes):
        if factory_scene != scene:
            bpy.data.scenes.remove(factory_scene)

    output = PACKAGE / "output"
    output.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix=".build-", dir=output) as scratch:
        staging = Path(scratch)
        save_model(scene, staging)
        if args.full:
            render_views(scene, staging)
        result = publish_build(staging, output)
    print(f"Build complete: {result}", flush=True)


if __name__ == "__main__":
    main()
