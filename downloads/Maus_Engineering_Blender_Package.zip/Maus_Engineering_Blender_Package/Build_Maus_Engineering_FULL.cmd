@echo off
call "%~dp0Build_Maus_Engineering.cmd" --full
exit /b %errorlevel%
