"""Steel Front — Maus Engineering Variant, editable Blender model.

In Blender, open this file in Scripting > Text Editor and choose Run Script.
The model is built in its own scene. Save your edited result as a .blend file.
Frame 1 shows the blade raised. Frame 36 shows the blade lowered.
Track shoes are linked instances of a single editable mesh.

Scale: metres. Ground: Z = 0. Front: -Y (becomes +Z in Y-up glTF).
Hull: 9.00 x 3.70 m excluding the blade. No external textures are needed.
"""

from math import cos, pi, radians, sin, tau
from typing import NamedTuple

import bpy
from mathutils import Matrix, Vector


class Dimensions(NamedTuple):
    length: float = 9.0
    width: float = 3.7
    hull_roof: float = 2.08
    clearance: float = 0.48
    track_width: float = 1.02
    turret_y: float = 0.87
    turret_length: float = 3.65
    turret_width: float = 2.85
    turret_height: float = 1.17
    barrel_length: float = 4.30


D = Dimensions()
SCENE_NAME = "Maus Engineering"
SCENE_KEY = "steel_front_maus_engineering"
FRONT = (pi / 2, 0, 0)
REAR = (-pi / 2, 0, 0)
REAR_MATRIX = Matrix.Rotation(REAR[0], 4, "X")
ACROSS = (0, pi / 2, 0)
FRAME_TRAVEL = 1
FRAME_WORK = 36


def linear_color(color):
    def channel(value):
        value /= 255.0
        return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4

    return tuple(channel(int(color[i:i + 2], 16)) for i in (0, 2, 4)) + (1.0,)


def material(name, color, roughness, metallic=0.0, grain=0.0, palette=None, anchor=None):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.diffuse_color = linear_color(color)
    mat.metallic = metallic
    mat.roughness = roughness
    tree = mat.node_tree
    shader = tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = mat.diffuse_color
    shader.inputs["Metallic"].default_value = metallic
    shader.inputs["Roughness"].default_value = roughness
    if palette or grain:
        coords = tree.nodes.new("ShaderNodeTexCoord")
        coords.location = (-760, 50)
        if anchor:
            coords.object = anchor
    if palette:
        noise = tree.nodes.new("ShaderNodeTexNoise")
        noise.inputs["Scale"].default_value = 1.65
        noise.inputs["Detail"].default_value = 2.1
        noise.inputs["Roughness"].default_value = 0.58
        noise.location = (-560, 200)
        ramp = tree.nodes.new("ShaderNodeValToRGB")
        ramp.label = "Olive and field-tan camouflage"
        ramp.location = (-320, 210)
        stops = (0.25, 0.405, 0.442, 0.585, 0.62, 0.77)
        ramp.color_ramp.elements.remove(ramp.color_ramp.elements[1])
        ramp.color_ramp.elements[0].position = stops[0]
        ramp.color_ramp.elements[0].color = linear_color(palette[0])
        for strength, tone in zip(stops[1:], (palette[0], color, color, palette[1], palette[1])):
            ramp.color_ramp.elements.new(strength).color = linear_color(tone)
        tree.links.new(coords.outputs["Object"], noise.inputs["Vector"])
        tree.links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
        tree.links.new(ramp.outputs["Color"], shader.inputs["Base Color"])
    if grain:
        grit = tree.nodes.new("ShaderNodeTexNoise")
        grit.inputs["Scale"].default_value = 105.0
        grit.inputs["Detail"].default_value = 2.0
        grit.location = (-555, -170)
        bump = tree.nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = grain
        bump.inputs["Distance"].default_value = 0.015
        bump.location = (-180, -160)
        tree.links.new(coords.outputs["Object"], grit.inputs["Vector"])
        tree.links.new(grit.outputs["Fac"], bump.inputs["Height"])
        tree.links.new(bump.outputs["Normal"], shader.inputs["Normal"])
    return mat


def make_materials(hull, turret):
    camo = ("424E40", "797050")
    return {
        "hull": material("01 Hull | olive camouflage", "666D51", 0.59, 0.22, 0.18, camo, hull),
        "turret": material("02 Turret | olive camouflage", "686D53", 0.60, 0.22, 0.18, camo, turret),
        "olive": material("03 Fittings | muted olive", "535A45", 0.63, 0.27, 0.16),
        "blade": material("04 Moldboard | worn steel", "4F5651", 0.68, 0.53, 0.28),
        "track": material("05 Track shoes | oxidized steel", "514B42", 0.69, 0.65, 0.28),
        "polished": material("06 Contact edges | burnished steel", "8C887C", 0.42, 0.75, 0.14),
        "dark": material("07 Recesses | carbon grey", "252A28", 0.76, 0.29, 0.20),
        "rubber": material("08 Wheel bands | charcoal", "292925", 0.84, 0.02, 0.16),
        "glass": material("09 Periscopes | blue-grey glass", "5B7879", 0.24, 0.32),
        "lamp": material("10 Lamps | warm glass", "C6C0A1", 0.28, 0.15),
        "amber": material("11 Recovery markings | faded ochre", "B89549", 0.61, 0.16),
        "exhaust": material("12 Exhaust | heat-stained steel", "544539", 0.70, 0.61, 0.28),
    }


def child_collection(name, parent):
    collection = bpy.data.collections.new(name)
    parent.children.link(collection)
    return collection


def pivot(name, collection, parent=None, position=(0, 0, 0), size=0.22):
    obj = bpy.data.objects.new(name, None)
    collection.objects.link(obj)
    obj.empty_display_type = "PLAIN_AXES"
    obj.empty_display_size = size
    obj.parent = parent
    obj.location = position
    return obj


class MeshParts:
    """Small mesh builder for reusable wheels, track shoes and lathes."""

    def __init__(self):
        self.vertices = []
        self.faces = []
        self.face_materials = []
        self.smooth = []

    def add(self, vertices, faces, color, smooth=False):
        offset = len(self.vertices)
        self.vertices.extend(vertices)
        self.faces.extend(tuple(offset + index for index in face) for face in faces)
        self.face_materials.extend([color] * len(faces))
        self.smooth.extend([smooth] * len(faces) if isinstance(smooth, bool) else smooth)

    def box(self, size, at=(0, 0, 0), color="olive"):
        hx, hy, hz = (value / 2 for value in size)
        cx, cy, cz = at
        points = [(-hx, -hy), (hx, -hy), (hx, hy), (-hx, hy)]
        vertices = [(cx + x, cy + y, cz + z) for z in (-hz, hz) for x, y in points]
        faces = [(3, 2, 1, 0), (4, 5, 6, 7)]
        faces.extend((i, (i + 1) % 4, (i + 1) % 4 + 4, i + 4) for i in range(4))
        self.add(vertices, faces, color)

    def lathe(self, rings, sides, color, at=(0, 0, 0), inside_after=None):
        # Rings are (axial position, radius). Axis is local +Z.
        cx, cy, cz = at
        vertices = [
            (cx + radius * cos(tau * i / sides), cy + radius * sin(tau * i / sides), cz + z)
            for z, radius in rings for i in range(sides)
        ]
        offset = len(self.vertices)
        self.vertices.extend(vertices)
        self._face(tuple(offset + i for i in reversed(range(sides))), color, False)
        for row in range(len(rings) - 1):
            first = offset + row * sides
            normal_color = "dark" if inside_after is not None and row >= inside_after else color
            smooth = rings[row][0] != rings[row + 1][0]
            for i in range(sides):
                j = (i + 1) % sides
                self._face((first + i, first + j, first + sides + j, first + sides + i), normal_color, smooth)
        last = offset + (len(rings) - 1) * sides
        self._face(tuple(last + i for i in range(sides)), "dark" if inside_after is not None else color, False)

    def _face(self, face, color, smooth):
        self.faces.append(face)
        self.face_materials.append(color)
        self.smooth.append(smooth)

    def data(self, name, materials):
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(self.vertices, [], self.faces)
        mesh.update()
        slots = {key: i for i, key in enumerate(dict.fromkeys(self.face_materials))}
        for key in slots:
            mesh.materials.append(materials[key])
        for face, color, smooth in zip(mesh.polygons, self.face_materials, self.smooth):
            face.material_index = slots[color]
            face.use_smooth = smooth
        return mesh


def from_rings(rings):
    """Closed loft whose rings run counter-clockwise viewed from above."""
    count = len(rings[0])
    vertices = [v for ring in rings for v in ring]
    faces = [tuple(reversed(range(count)))]
    for row in range(len(rings) - 1):
        start = row * count
        for i in range(count):
            j = (i + 1) % count
            faces.append((start + i, start + j, start + count + j, start + count + i))
    cap = (len(rings) - 1) * count
    faces.append(tuple(range(cap, cap + count)))
    return vertices, faces


def deck_ring(z, half, front, rear, corner):
    return [(x, y, z) for x, y in (
        (-half + corner, front), (half - corner, front), (half, front + corner),
        (half, rear - corner), (half - corner, rear), (-half + corner, rear),
        (-half, rear - corner), (-half, front + corner),
    )]


class Parts:
    def __init__(self, collection, parent, materials):
        self.collection = collection
        self.parent = parent
        self.materials = materials

    def obj(self, name, mesh, at=(0, 0, 0), rotation=(0, 0, 0), bevel=0.0):
        obj = bpy.data.objects.new(name, mesh)
        self.collection.objects.link(obj)
        obj.parent = self.parent
        obj.location = at
        obj.rotation_euler = rotation
        if bevel > 0.0:
            chamfer = obj.modifiers.new("Edge bevel", "BEVEL")
            chamfer.width = bevel
            chamfer.segments = 2
            chamfer.limit_method = "ANGLE"
            normal = obj.modifiers.new("Face normals", "WEIGHTED_NORMAL")
            normal.keep_sharp = True
        return obj

    def mesh(self, name, vertices, faces, color, bevel=0.0):
        parts = MeshParts()
        parts.add(vertices, faces, color)
        return self.obj(name, parts.data(name, self.materials), bevel=bevel)

    def loft(self, name, rings, color, bevel=0.0):
        return self.mesh(name, *from_rings(rings), color, bevel)

    def box(self, name, size, at, color, bevel=0.0, rotation=(0, 0, 0)):
        parts = MeshParts()
        parts.box(size, color=color)
        return self.obj(name, parts.data(name, self.materials), at, rotation, bevel)

    def cylinder(self, name, radius, length, at, color, rotation=(0, 0, 0), sides=24):
        parts = MeshParts()
        parts.lathe(((-length / 2, radius), (length / 2, radius)), sides, color)
        return self.obj(name, parts.data(name, self.materials), at, rotation)

    def beam(self, name, start, end, section, color, bevel=0.0):
        a, b = Vector(start), Vector(end)
        delta = b - a
        return self.box(name, (section[0], delta.length, section[1]), (a + b) / 2,
                        color, bevel, delta.to_track_quat("Y", "Z").to_euler())

    def ring(self, name, radius, thickness, at, color, rotation=(0, 0, 0)):
        sections, tube_sides = 20, 8
        rings = []
        for i in range(sections):
            angle = tau * i / sections
            rings.extend(((radius + thickness * cos(tau * j / tube_sides)) * cos(angle),
                          (radius + thickness * cos(tau * j / tube_sides)) * sin(angle),
                          thickness * sin(tau * j / tube_sides)) for j in range(tube_sides))
        faces = []
        for i in range(sections):
            a, b = i * tube_sides, ((i + 1) % sections) * tube_sides
            for j in range(tube_sides):
                k = (j + 1) % tube_sides
                faces.append((a + j, b + j, b + k, a + k))
        mesh = MeshParts()
        mesh.add(rings, faces, color, True)
        return self.obj(name, mesh.data(name, self.materials), at, rotation)


def build_hull(p):
    half_len = D.length / 2
    p.loft("Lower hull · bevelled armor", [
        deck_ring(D.clearance, 1.06, -3.74, 4.18, 0.32),
        deck_ring(0.90, 1.18, -4.34, 4.40, 0.26),
        deck_ring(1.26, 1.29, -half_len, half_len, 0.24),
    ], "olive", 0.045)
    p.loft("Upper hull · sloped glacis", [
        deck_ring(1.15, 1.70, -4.43, 4.43, 0.29),
        deck_ring(1.43, 1.81, -half_len, half_len, 0.32),
        deck_ring(D.hull_roof, 1.65, -3.40, 4.02, 0.31),
    ], "hull", 0.068)
    p.cylinder("Turret race", 1.12, 0.17, (0, D.turret_y, 2.07), "dark", sides=48)
    for side, suffix in ((-1, "L"), (1, "R")):
        # Three removable fender sections leave the wheels visible underneath.
        for i, y in enumerate((-2.89, -0.18, 2.55), 1):
            x = side * 1.71
            p.box(f"Side skirt {suffix} {i:02d}", (0.27, 2.67, 0.44), (x, y, 1.33),
                  "hull", 0.04)
            p.box(f"Skirt rail {suffix} {i:02d}", (0.055, 2.63, 0.066),
                  (side * 1.83, y, 1.19), "dark", 0.012)
            for j, dy in enumerate((-1.03, -0.37, 0.37, 1.03), 1):
                p.cylinder(f"Skirt bolt {suffix} {i:02d}.{j}", 0.032, 0.018,
                           (side * 1.847, y + dy, 1.47), "olive", ACROSS, 6)
        # Armored lamps and tow eyes near the nose and tail.
        x = side * 1.24
        p.box(f"Lamp saddle {suffix}", (0.28, 0.29, 0.22), (x, -4.02, 1.67), "hull", 0.035)
        p.cylinder(f"Lamp housing {suffix}", 0.12, 0.145, (x, -4.10, 1.76), "dark", FRONT)
        p.cylinder(f"Lamp glass {suffix}", 0.083, 0.017, (x, -4.18, 1.76), "lamp", FRONT)
        p.beam(f"Lamp guard {suffix}", (x - 0.13, -4.21, 1.80), (x + 0.13, -4.21, 1.80),
               (0.025, 0.025), "olive")
        for end, y, height in (("Front", -4.37, 1.00), ("Rear", 4.39, 1.29)):
            p.box(f"{end} towing lug {suffix}", (0.20, 0.28, 0.18), (x, y, height),
                  "olive", 0.032)
            p.ring(f"{end} towing eye {suffix}", 0.087, 0.031,
                   (x, y + (0.15 if end == "Rear" else -0.15), height - 0.03),
                   "polished", FRONT)
        hatch_x = side * 0.57
        p.box(f"Forward deck hatch {suffix}", (0.64, 0.66, 0.075), (hatch_x, -2.11, 2.11),
              "hull", 0.044)
        p.box(f"Hatch hinge {suffix}", (0.66, 0.08, 0.087), (hatch_x, -1.86, 2.16),
              "olive", 0.018)
        p.box(f"Driver vision block {suffix}", (0.25, 0.11, 0.13), (hatch_x, -2.56, 2.15),
              "olive", 0.018)
        p.box(f"Driver lens {suffix}", (0.20, 0.016, 0.051), (hatch_x, -2.62, 2.16), "glass")
        # Exposed parts stay separate so the outer armor can be refined independently.
        p.box(f"Rear intake recess {suffix}", (0.91, 1.13, 0.055),
              (side * 0.78, 3.33, 2.11), "dark", 0.035)
        for i in range(9):
            p.box(f"Intake slat {suffix} {i + 1:02d}", (0.88, 0.055, 0.054),
                  (side * 0.78, 2.85 + i * 0.12, 2.143), "olive", 0.008)
        p.cylinder(f"Exhaust outlet {suffix}", 0.121, 0.23,
                   (side * 0.80, 4.26, 1.70), "exhaust", REAR)
        p.cylinder(f"Exhaust recess {suffix}", 0.086, 0.022,
                   (side * 0.80, 4.382, 1.70), "dark", REAR)
    p.box("Rear center access cover", (0.49, 0.86, 0.075), (0, 3.42, 2.12), "hull", 0.035)
    p.box("Rear convoy lamp", (0.17, 0.14, 0.10), (0, 4.39, 1.66), "olive", 0.018)
    p.box("Rear convoy lens", (0.10, 0.019, 0.055), (0, 4.47, 1.66), "amber")


def build_turret(p, gun, socket_collection):
    half_w, half_l = D.turret_width / 2, D.turret_length / 2
    outline = (
        (-0.59, -1), (0.59, -1), (0.84, -0.91), (0.97, -0.71), (1, -0.42),
        (1, 0.68), (0.93, 0.96), (0.79, 1), (-0.79, 1), (-0.93, 0.96),
        (-1, 0.68), (-1, -0.42), (-0.97, -0.71), (-0.84, -0.91),
    )
    p.loft("Turret armor · rounded cheeks", [
        [(x * half_w * scale_x, y * half_l * scale_y, z) for x, y in outline]
        for z, scale_x, scale_y in (
            (0.085, 0.92, 0.92), (0.24, 1.0, 1.0),
            (D.turret_height - 0.14, 0.96, 0.96), (D.turret_height, 0.88, 0.90),
        )
    ], "turret", 0.072)
    h = D.turret_height
    p.box("Rear bustle access cover", (1.50, 0.13, 0.45), (0, 1.72, 0.59), "turret", 0.065)
    for x in (-0.58, 0.0, 0.58):
        p.cylinder(f"Bustle fastener {x:+.2f}", 0.042, 0.030, (x, 1.80, 0.64), "polished", REAR, 6)
    p.cylinder("Commander cupola", 0.36, 0.17, (0.59, 0.58, h + 0.06), "turret", sides=36)
    p.cylinder("Commander hatch", 0.31, 0.057, (0.59, 0.58, h + 0.166), "olive", sides=32)
    for i in range(6):
        a = tau * i / 6
        p.box(f"Cupola vision block {i + 1}", (0.135, 0.046, 0.062),
              (0.59 + 0.344 * sin(a), 0.58 + 0.344 * cos(a), h + 0.081),
              "glass", 0.011, (0, 0, -a))
    p.box("Loader hatch", (0.69, 0.66, 0.072), (-0.55, 0.42, h + 0.056), "turret", 0.05)
    p.box("Loader hatch hinge", (0.65, 0.074, 0.07), (-0.55, 0.70, h + 0.096), "olive", 0.015)
    p.box("Gunner periscope guard", (0.35, 0.27, 0.17), (-0.53, -0.77, h + 0.087),
          "olive", 0.026)
    p.box("Gunner periscope lens", (0.22, 0.017, 0.066),
          (-0.53, -0.91, h + 0.094), "glass", 0.007)
    for side in (-1, 1):
        p.ring(f"Turret lift eye {side:+d}", 0.093, 0.024, (side * 0.95, 1.00, h + 0.07),
               "polished", FRONT)
    p.cylinder("Antenna base", 0.084, 0.12, (-0.79, 1.14, h + 0.062), "dark", sides=12)
    p.cylinder("Antenna mast", 0.011, 0.64, (-0.79, 1.14, h + 0.44), "dark",
               (0.12, -0.10, 0), 8)

    # Only the visible external geometry. The empty at the muzzle helps game integration.
    gun.box("Gun mantlet · rotating with barrel", (1.48, 0.56, 0.69),
            (0, -0.19, 0), "turret", 0.10)
    sleeve = MeshParts()
    sleeve.lathe(((-0.16, 0.29), (0.04, 0.34), (0.50, 0.29), (0.75, 0.20)), 36, "olive")
    gun.obj("Gun sleeve", sleeve.data("Gun sleeve", gun.materials), rotation=FRONT)
    barrel = MeshParts()
    barrel.lathe(((0.25, 0.164), (0.82, 0.159), (1.01, 0.131), (1.21, 0.127),
                  (3.92, 0.082), (4.12, 0.082), (4.18, 0.098), (D.barrel_length, 0.098),
                  (D.barrel_length, 0.046), (4.06, 0.046)),
                 40, "blade", inside_after=8)
    gun.obj("Main barrel · recessed muzzle", barrel.data("Main barrel", gun.materials), rotation=FRONT)
    socket = pivot("MUZZLE_SOCKET", socket_collection, gun.parent, (0, -D.barrel_length, 0), 0.13)
    socket["axis"] = "-Y forward."


def track_path(distance, axle, radius, height):
    straight = 2 * axle
    arc = pi * radius
    if distance < straight:
        return -axle + distance, height - radius, 0.0
    distance -= straight
    if distance < arc:
        angle = distance / radius - pi / 2
        return axle + radius * cos(angle), height + radius * sin(angle), angle + pi / 2
    distance -= arc
    if distance < straight:
        return axle - distance, height + radius, pi
    angle = (distance - straight) / radius + pi / 2
    return -axle + radius * cos(angle), height + radius * sin(angle), angle + pi / 2


def shoe_mesh(pitch, materials):
    shoe = MeshParts()
    shoe.box((D.track_width, pitch * 0.89, 0.065), color="track")
    shoe.box((D.track_width * 0.91, pitch * 0.25, 0.022), (0, 0.021, -0.039), "polished")
    shoe.box((0.17, pitch * 0.39, 0.115), (0, 0, 0.074), "track")
    for side in (-1, 1):
        shoe.box((0.077, pitch * 0.53, 0.043), (side * 0.453, -0.035, 0.028), "dark")
    return shoe.data("Interlinked wide-track shoe", materials)


def wheel_mesh(name, radius, width, materials, drive=False):
    wheel = MeshParts()
    wheel.lathe(((-width / 2, radius * 0.92), (-width * 0.42, radius),
                 (width * 0.43, radius), (width / 2, radius * 0.92)),
                28, "track" if drive else "rubber")
    wheel.lathe(((width * 0.33, radius * 0.80), (width * 0.50, radius * 0.88),
                 (width * 0.53, radius * 0.83), (width * 0.59, radius * 0.65)),
                28, "olive")
    wheel.lathe(((width * 0.55, radius * 0.45), (width * 0.65, radius * 0.45),
                 (width * 0.71, radius * 0.33)), 18, "blade")
    for i in range(8):
        a = tau * i / 8
        bolt = radius * 0.56
        wheel.lathe(((-0.012, 0.028), (0.012, 0.028)), 6, "polished",
                    (bolt * cos(a), bolt * sin(a), width * 0.60))
    if drive:
        for i in range(16):
            a = tau * i / 16
            wheel.lathe(((-0.021, 0.043), (0.021, 0.043)), 6, "polished",
                        (radius * 0.88 * cos(a), radius * 0.88 * sin(a), width * 0.51))
    return wheel.data(name, materials)


def build_running_gear(gear_collection, hull, materials):
    axle, radius, height = 3.90, 0.502, 0.552
    perimeter = 4 * axle + tau * radius
    count = round(perimeter / 0.205)
    pitch = perimeter / count
    shoe = shoe_mesh(pitch, materials)
    road = wheel_mesh("Paired road wheel profile", 0.340, 0.73, materials)
    idler = wheel_mesh("Front idler profile", 0.45, 0.72, materials)
    drive = wheel_mesh("Rear drive sprocket profile", 0.46, 0.74, materials, drive=True)
    x = (D.width - D.track_width) / 2
    for side, suffix in ((-1, "L"), (1, "R")):
        group = child_collection(suffix + " · track and wheels", gear_collection)
        track = pivot(f"TRACK_{suffix}", group, hull, (side * x, 0, 0))
        track["shoe_count"] = count
        belt = Parts(group, track, materials)
        for i in range(count):
            y, z, tilt = track_path(i * pitch, axle, radius, height)
            belt.obj(f"Shoe_{suffix}_{i + 1:03d}", shoe, (0, y, z), (tilt, 0, 0))
        wheel_rotation = (0, side * pi / 2, 0)
        belt.obj(f"Front_Idler_{suffix}", idler, (0, -axle, height), wheel_rotation)
        belt.obj(f"Rear_Sprocket_{suffix}", drive, (0, axle, height), wheel_rotation)
        for i in range(9):
            y = -3.25 + i * (6.50 / 8)
            belt.obj(f"Road_Wheel_{suffix}_{i + 1:02d}", road, (0, y, 0.423), wheel_rotation)


def moldboard(parts):
    width = D.width + 0.36
    heights = (-0.42, -0.32, -0.10, 0.12, 0.31, 0.43)
    depths = (-0.22, -0.16, 0.02, 0.115, 0.057, -0.033)
    columns = (-1.0, -0.89, -0.70, -0.45, 0.0, 0.45, 0.70, 0.89, 1.0)
    # Thicker end plates turn forward to retain soil around the curved blade.
    vertices = [(u * width / 2, y + thickness - 0.20 * max(0, abs(u) - 0.70) / 0.30,
                 z - 0.045 * max(0, abs(u) - 0.85) / 0.15)
                for thickness in (0.0, 0.115) for z, y in zip(heights, depths) for u in columns]
    rows, cols = len(heights), len(columns)
    offset = rows * cols
    faces = []
    for r in range(rows - 1):
        for c in range(cols - 1):
            a = r * cols + c
            quad = (a, a + 1, a + cols + 1, a + cols)
            faces.append(quad)
            faces.append(tuple(i + offset for i in reversed(quad)))
    perimeter = list(range(cols))
    perimeter += [r * cols + cols - 1 for r in range(1, rows)]
    perimeter += list(range(offset - 2, offset - cols - 1, -1))
    perimeter += [r * cols for r in range(rows - 2, 0, -1)]
    for i, a in enumerate(perimeter):
        b = perimeter[(i + 1) % len(perimeter)]
        faces.append((b, a, a + offset, b + offset))
    parts.mesh("Curved bulldozer moldboard", vertices, faces, "blade", 0.014)
    # Replaceable edge segments follow the same frontal sweep as the moldboard.
    for i in range(len(columns) - 1):
        u, v = columns[i:i + 2]
        def lip(f):
            return (f * width / 2, -0.227 - 0.20 * max(0, abs(f) - 0.70) / 0.30, -0.394)
        a, b = lip(u), lip(v)
        parts.beam(f"Cutting edge {i + 1:02d}", a, b, (0.123, 0.091), "polished", 0.012)
        for j, point in enumerate((Vector(a).lerp(Vector(b), 0.27), Vector(a).lerp(Vector(b), 0.73)), 1):
            point.y -= 0.065
            parts.cylinder(f"Cutting edge bolt {i + 1:02d}.{j}", 0.032, 0.018, point,
                           "dark", FRONT, 6)
    profile = list(zip(heights[1:-1], depths[1:-1]))
    rib = [(y + 0.10, z) for z, y in reversed(profile)] + [(y + 0.25, z) for z, y in profile]
    for x in (-1.23, -0.66, 0, 0.66, 1.23):
        sections = [[(edge, y, z) for y, z in rib] for edge in (x - 0.045, x + 0.045)]
        parts.loft(f"Moldboard rear stiffener {x:+.2f}", sections, "olive", 0.014)


def build_blade(scene, collection, hull, materials):
    lift = pivot("DOZER_LIFT_PIVOT", collection, hull, (0, -3.47, 0.65), 0.26)
    lift["channel"] = "Rotate on local X to lift the full linkage."
    blade = pivot("BLADE_PIVOT", collection, lift, (0, -1.54, 0), 0.23)
    blade.rotation_euler.x = 0.031
    blade["channel"] = "Local X controls the moldboard pitch."
    fixed = Parts(collection, hull, materials)
    linkage = Parts(collection, lift, materials)
    plow = Parts(collection, blade, materials)
    moldboard(plow)

    for side, suffix in ((-1, "L"), (1, "R")):
        x = side * 1.33
        fixed.box(f"Dozer chassis bracket {suffix}", (0.38, 0.54, 0.48), (x, -3.45, 0.84),
                  "hull", 0.044)
        fixed.cylinder(f"Dozer chassis hinge pin {suffix}", 0.104, 0.43, (x, -3.47, 0.65),
                       "polished", ACROSS, 16)
        linkage.beam(f"Armoured push arm {suffix}", (x, 0.01, 0.0), (side * 1.23, -1.30, -0.09),
                     (0.22, 0.24), "olive", 0.039)
        plow.box(f"Blade rear arm saddle {suffix}", (0.25, 0.24, 0.22),
                 (side * 1.23, 0.244, -0.09), "blade", 0.038)

        # The rod reaches the blade anchor and slides under the rigid ram body.
        pin_x = side * 1.48
        anchor = pivot(f"DOZER_RAM_END_{suffix}", collection, blade, (pin_x, 0.24, 0.13), 0.09)
        plow.cylinder(f"Moldboard ram pin {suffix}", 0.054, 0.20, (pin_x, 0.24, 0.13),
                      "polished", ACROSS, 14)
        housing = pivot(f"DOZER_RAM_BASE_{suffix}", collection, hull, (pin_x, -3.72, 1.48), 0.11)
        aim = housing.constraints.new("DAMPED_TRACK")
        aim.target = anchor
        aim.track_axis = "TRACK_Y"
        fixed.box(f"Ram chassis clevis {suffix}", (0.24, 0.18, 0.22),
                  (pin_x, -3.67, 1.48), "olive", 0.028)
        tube = Parts(collection, housing, materials)
        tube.cylinder(f"Hydraulic cylinder {suffix}", 0.093, 0.70, (0, 0.36, 0), "olive", REAR)
        tube.cylinder(f"Cylinder gland {suffix}", 0.104, 0.073, (0, 0.69, 0), "dark", REAR)
        rod_geometry = MeshParts()
        rod_geometry.lathe(((0.0, 0.049), (1.0, 0.049)), 20, "polished")
        rod = fixed.obj(f"Hydraulic piston rod {suffix}",
                        rod_geometry.data(f"Piston rod {suffix}", materials), housing.location)
        # Local +Y is the stretch axis. Keep the geometry as an editable mesh.
        rod.data.transform(REAR_MATRIX)
        constraint = rod.constraints.new("STRETCH_TO")
        constraint.target = anchor
        constraint.rest_length = 1.0
        constraint.volume = "NO_VOLUME"

    for frame, angle in ((FRAME_TRAVEL, -21.75), (FRAME_WORK, 6.30)):
        lift.rotation_euler.x = radians(angle)
        lift.keyframe_insert(data_path="rotation_euler", index=0, frame=frame)
    scene.frame_start, scene.frame_end = FRAME_TRAVEL, FRAME_WORK
    scene.timeline_markers.new("Blade raised", frame=FRAME_TRAVEL)
    scene.timeline_markers.new("Blade lowered", frame=FRAME_WORK)


def lighting(scene):
    studio = child_collection("Studio · camera and lights", scene.collection)
    floor_mat = material("Studio floor | slate", "32383D", 0.75, 0.0, 0.05)
    floor = Parts(studio, None, {"floor": floor_mat})
    floor.box("Studio ground", (420.0, 420.0, 0.12), (0, 0, -0.066), "floor")

    def aim(obj, target):
        obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()

    def area(name, at, target, power, size, color):
        data = bpy.data.lights.new(name, "AREA")
        data.energy, data.size, data.color = power, size, color
        obj = bpy.data.objects.new(name, data)
        studio.objects.link(obj)
        obj.location = at
        aim(obj, target)

    area("Key · soft warm light", (6, -8, 10), (0, -1, 1), 2550, 7.5, (1.0, 0.88, 0.72))
    area("Fill · blue-grey", (-7, -4, 5), (0, 0, 1), 1550, 6.5, (0.72, 0.84, 1.0))
    area("Rim · deck", (1, 8, 8.5), (0, 1, 1), 3200, 6.0, (0.90, 0.95, 1.0))

    data = bpy.data.cameras.new("Engineering three-quarter")
    camera = bpy.data.objects.new("Engineering three-quarter", data)
    studio.objects.link(camera)
    camera.location = (11.8, -15.2, 6.8)
    aim(camera, (0, -0.63, 1.25))
    data.lens = 52
    scene.camera = camera

    world = bpy.data.worlds.new("Maus Studio")
    world.use_nodes = True
    world.node_tree.nodes.get("Background").inputs[0].default_value = (0.115, 0.14, 0.17, 1.0)
    world.node_tree.nodes.get("Background").inputs[1].default_value = 0.45
    scene.world = world
    scene.render.resolution_x, scene.render.resolution_y = 1440, 960
    scene.render.resolution_percentage = 100
    scene.view_settings.view_transform = "AgX" if bpy.app.version >= (4, 0, 0) else "Filmic"
    return studio


def present(scene):
    window = bpy.context.window
    if window is None:
        return
    window.scene = scene
    camera = scene.camera
    if camera is None:
        return
    for area in window.screen.areas:
        if area.type == "VIEW_3D":
            space = area.spaces.active
            space.region_3d.view_rotation = camera.rotation_euler.to_quaternion()
            space.region_3d.view_location = Vector((0, -0.62, 1.20))
            space.region_3d.view_distance = 15.0
            space.region_3d.view_perspective = "PERSP"
            space.shading.color_type = "MATERIAL"
            space.overlay.show_extras = False


def build_scene():
    # Reopening the script focuses the existing generated scene. User edits are kept.
    existing = next((s for s in bpy.data.scenes if s.get(SCENE_KEY) == 1), None)
    if existing:
        present(existing)
        return existing

    scene = bpy.data.scenes.new(SCENE_NAME)
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.length_unit = "METERS"
    asset = child_collection("Maus_Engineering · vehicle asset", scene.collection)
    hull_collection = child_collection("01 · Hull", asset)
    turret_collection = child_collection("02 · Turret and gun", asset)
    gear_collection = child_collection("03 · Running gear", asset)
    blade_collection = child_collection("04 · Dozer assembly", asset)

    root = pivot("MAUS_ENG_ROOT", asset, size=0.45)
    root["vehicle_id"] = "mauseng"
    root["scale"] = "1 Blender unit = 1 m"
    root["orientation"] = "-Y forward, +Z up, origin at ground centre"
    root["hull_length_m"] = D.length
    root["hull_width_m"] = D.width
    hull = pivot("HULL", hull_collection, root)
    turret = pivot("TURRET_PIVOT", turret_collection, hull, (0, D.turret_y, D.hull_roof))
    turret["channel"] = "Local Z rotates the turret."
    gun = pivot("GUN_PIVOT", turret_collection, turret,
                (0, -D.turret_length * 0.43, D.turret_height * 0.44))
    gun["channel"] = "Local X controls elevation."

    mats = make_materials(hull, turret)
    build_hull(Parts(hull_collection, hull, mats))
    build_turret(Parts(turret_collection, turret, mats), Parts(turret_collection, gun, mats), turret_collection)
    build_running_gear(gear_collection, hull, mats)
    build_blade(scene, blade_collection, hull, mats)
    studio = lighting(scene)

    present(scene)
    view_layer = scene.view_layers[0]
    for obj in studio.objects:
        obj.hide_set(True, view_layer=view_layer)
    root.select_set(True, view_layer=view_layer)
    view_layer.objects.active = root
    scene.frame_set(FRAME_TRAVEL)
    scene[SCENE_KEY] = 1
    print("Maus Engineering: model ready. Frame 1 raised; frame 36 lowered.")
    return scene


if __name__ == "__main__":
    build_scene()
